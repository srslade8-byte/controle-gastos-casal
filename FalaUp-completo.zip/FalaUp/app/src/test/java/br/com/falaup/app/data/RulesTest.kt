package br.com.falaup.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class RulesTest {
    private val day1 = LocalDate.of(2026, 10, 25)

    private fun session(seconds: Int, ts: Long, fillers: Int = -1) = SpeakingSession(
        timestamp = ts, topic = "tema", plannedSeconds = 60, actualSeconds = seconds,
        criteriaMet = 3, fillerCount = fillers, audioFile = "a.m4a"
    )

    @Test fun conteudoEstaConsistente() {
        assertEquals((1..lessons.size).toList(), lessons.map { it.id })
        lessons.forEach { l ->
            l.questions.forEach { q ->
                if (q.kind == QuestionKind.CHOICE) {
                    assertEquals(4, q.options.size)
                    assertTrue(q.correct in q.options.indices)
                } else {
                    assertTrue(q.options.size >= 3)
                    assertFalse(q.displayOrder() == q.options.indices.toList())
                }
            }
        }
    }

    @Test fun apenasPrimeiraLicaoComecaLiberada() {
        val s = ProgressState()
        assertTrue(Rules.isUnlocked(s, lessons[0]))
        assertFalse(Rules.isUnlocked(s, lessons[1]))
    }

    @Test fun reprovarNaoDaXpNemConclui() {
        val o = Rules.finishLesson(ProgressState(), lessons[0], 1, setOf(0, 2), day1)
        assertFalse(o.passed)
        assertEquals(0, o.state.xp)
        assertTrue(o.state.completed.isEmpty())
        assertEquals(setOf("1:0", "1:2"), o.state.wrong)
    }

    @Test fun passarDaXpUmaUnicaVez() {
        var o = Rules.finishLesson(ProgressState(), lessons[0], 2, setOf(2), day1)
        assertEquals(20, o.xpEarned)
        o = Rules.finishLesson(o.state, lessons[0], 3, emptySet(), day1)
        assertEquals(0, o.xpEarned)
        assertEquals(20, o.state.xp)
        assertTrue("perfect" in o.state.achievements)
    }

    @Test fun revisaoDaXpUmaVezPorQuestao() {
        val s = ProgressState(wrong = setOf("1:2"))
        var o = Rules.answerReview(s, "1:2", true, day1)
        assertEquals(Rules.REVIEW_XP, o.xpEarned)
        o = Rules.answerReview(o.state, "1:2", true, day1)
        assertEquals(0, o.xpEarned)
    }

    @Test fun sequenciaContaEZera() {
        var s = Rules.finishLesson(ProgressState(), lessons[0], 3, emptySet(), day1).state
        s = Rules.finishLesson(s, lessons[1], 3, emptySet(), day1.plusDays(1)).state
        assertEquals(2, s.streak)
        assertEquals(0, Rules.currentStreak(s, day1.plusDays(4)))
        s = Rules.finishLesson(s, lessons[2], 3, emptySet(), day1.plusDays(4)).state
        assertEquals(1, s.streak)
        assertEquals(2, s.longestStreak)
    }

    @Test fun treinoDeFalaTemLimiteDiarioEDuracaoMinima() {
        var s = ProgressState()
        assertEquals(0, Rules.addSession(s, session(5, 1), day1).xpEarned)
        var total = 0
        for (i in 2..6) {
            val o = Rules.addSession(s, session(40, i.toLong()), day1)
            s = o.state; total += o.xpEarned
        }
        assertEquals(Rules.SPEECH_XP * Rules.MAX_SPEECH_XP_PER_DAY, total)
    }

    @Test fun conquistaDeVicios() {
        var s = ProgressState()
        for ((i, f) in listOf(2, 0, 5).withIndex()) s = Rules.addSession(s, session(40, i.toLong(), f), day1).state
        assertTrue("fillers_aware" in s.achievements)
    }

    @Test fun ordenarCorrigeCerto() {
        val q = lessons.flatMap { it.questions }.first { it.kind == QuestionKind.ORDER }
        assertTrue(q.isCorrect(q.options.indices.joinToString(",")))
        assertFalse(q.isCorrect(q.options.indices.reversed().joinToString(",")))
        assertFalse(q.isComplete("0"))
    }
}
