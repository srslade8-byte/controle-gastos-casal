package br.com.falaup.app.data

private fun q(prompt: String, correct: Int, explanation: String, vararg options: String) =
    Question(prompt, options.toList(), correct, explanation)

/** Questão de ordenar: passe os itens JÁ NA ORDEM CORRETA; o app os embaralha na tela. */
private fun ord(prompt: String, explanation: String, vararg itemsInOrder: String) =
    Question(prompt, itemsInOrder.toList(), 0, explanation, QuestionKind.ORDER)

val lessons: List<Lesson> = listOf(
    Lesson(
        1, "UNIDADE 1 · FUNDAMENTOS", "O que é comunicar bem?", 4,
        "Entender que comunicar bem é ser compreendido, não apenas falar.",
        "Comunicar bem não é falar muito nem usar palavras difíceis. É transmitir uma ideia de modo que outra pessoa consiga compreendê-la. Para isso, considere três pontos: quem está ouvindo, em que contexto você fala e qual é o objetivo da mensagem.",
        "No trabalho, dizer “faz aquilo depois” gera dúvidas. Dizer “registre os pedidos na planilha antes das 15h” deixa claro o que fazer e até quando.",
        listOf(
            q("Qual é o principal objetivo de uma comunicação eficaz?", 1, "A comunicação funciona quando a mensagem é transmitida e compreendida.",
                "Falar o máximo possível", "Fazer a mensagem ser compreendida", "Usar palavras difíceis", "Nunca fazer pausas"),
            q("Qual frase é mais clara?", 2, "Ela indica a ação (enviar o relatório) e o prazo (até as 16h).",
                "Faz aquilo depois", "Resolve essa coisa", "Envie o relatório até as 16h", "Você já sabe o que fazer"),
            q("Antes de falar, quais três pontos ajudam a adaptar a mensagem?", 3, "Público, contexto e objetivo orientam o que dizer e como dizer.",
                "Volume, velocidade e sotaque", "Roupa, local e horário", "Tema, título e slides", "Público, contexto e objetivo")
        ),
        "Pense em uma instrução vaga que você já recebeu ou deu. Reescreva-a dizendo o que, como e até quando."
    ),
    Lesson(
        2, "UNIDADE 1 · FUNDAMENTOS", "Vencendo o medo de falar", 5,
        "Reconhecer o nervosismo como algo comum e aprender formas práticas de lidar com ele.",
        "Sentir nervosismo antes de falar é muito comum e não significa que você fala mal. O corpo se prepara para um momento importante: o coração acelera e as mãos podem suar. Preparar o início da fala, respirar com calma e treinar em voz alta reduzem a insegurança. O foco deve sair de “como estão me julgando” e ir para “o que quero que entendam”.",
        "Antes de começar, solte o ar devagar duas vezes, apoie os pés no chão e diga a primeira frase que você já deixou preparada. Começar bem dá segurança para o resto.",
        listOf(
            q("Sentir nervosismo antes de falar em público…", 2, "É uma reação comum; com preparo e prática, ela pode ser administrada.",
                "Prova que você não tem talento", "Só acontece com iniciantes", "É comum e pode ser administrado", "Deve ser escondido a qualquer custo"),
            q("Qual atitude ajuda a começar com mais segurança?", 0, "Ter a primeira frase pronta reduz o risco de travar no início.",
                "Deixar a primeira frase preparada", "Começar sem planejar", "Pedir desculpas por estar nervoso", "Falar o mais rápido possível"),
            q("Onde é melhor colocar o foco durante a fala?", 1, "Pensar no que você quer que o público entenda tira o foco da autocrítica.",
                "Nos erros que podem acontecer", "Na mensagem que você quer transmitir", "Em quem parece entediado", "No relógio")
        ),
        "Escreva a primeira frase de uma apresentação sua. Em seguida, treine dizê-la em voz alta três vezes."
    ),
    Lesson(
        3, "UNIDADE 2 · ORGANIZAÇÃO", "A ideia principal", 5,
        "Identificar a mensagem central antes de montar uma fala.",
        "Antes de explicar algo, identifique a mensagem central: aquilo que o ouvinte deve levar da sua fala. Depois, escolha apenas os detalhes que ajudam a entendê-la. Isso evita começar vários assuntos e terminar sem responder ao ponto principal.",
        "Ideia central: “Precisamos organizar o estoque para reduzir atrasos.” Os detalhes explicam como será feito e que resultado se espera.",
        listOf(
            q("Antes de começar uma explicação, o que ajuda mais?", 1, "A ideia principal funciona como o eixo da explicação.",
                "Falar tudo o que vier à cabeça", "Definir a ideia principal", "Começar pelo detalhe mais complicado", "Memorizar um texto inteiro"),
            q("Qual é o melhor sinal de uma explicação organizada?", 3, "Uma sequência lógica ajuda o ouvinte a acompanhar o raciocínio.",
                "Mudar de assunto várias vezes", "Usar frases longas", "Evitar exemplos", "Ter uma sequência lógica"),
            q("Um detalhe deve entrar na fala quando…", 0, "Detalhes servem à ideia principal; o que não ajuda pode ser cortado.",
                "Ajuda a entender a ideia principal", "É interessante, mesmo sem relação", "Você tem tempo sobrando", "Ninguém conhece o assunto")
        ),
        "Escolha um assunto que você domina e resuma a ideia principal em uma única frase."
    ),
    Lesson(
        4, "UNIDADE 2 · ORGANIZAÇÃO", "Clareza e objetividade", 5,
        "Ser direto sem perder informações importantes.",
        "Ser objetivo não significa ser seco nem cortar informações essenciais. Significa incluir o necessário, em ordem fácil de acompanhar, evitando repetições e rodeios que não acrescentam sentido. Frases mais curtas e palavras simples costumam ajudar.",
        "Em vez de “eu queria só falar que talvez a gente pudesse começar”, diga “podemos começar agora”. Se houver uma condição importante, explique-a também.",
        listOf(
            q("Ser objetivo significa…", 2, "Objetividade preserva as informações importantes e corta o excesso.",
                "Falar sempre de forma curta, mesmo incompleta", "Usar palavras difíceis", "Transmitir o necessário sem rodeios", "Eliminar todos os exemplos"),
            q("Qual versão é mais objetiva?", 0, "Ela diz o essencial: o que fazer e quando.",
                "A reunião será amanhã às 9h.", "Então, tipo, eu acho que talvez a gente pudesse ter uma reunião em algum momento amanhã.", "Sobre a reunião, bem, é que, enfim, amanhã de manhã, possivelmente.", "Vamos ver se rola uma reunião."),
            q("Quando um exemplo é útil?", 1, "O exemplo deve tornar o conceito mais fácil de compreender.",
                "Sempre, mesmo sem relação", "Quando esclarece uma ideia", "Quando muda o assunto", "Nunca")
        ),
        "Pegue uma explicação sua de 4 frases e reescreva em 2, sem perder o que é essencial."
    ),
    Lesson(
        5, "UNIDADE 2 · ORGANIZAÇÃO", "Começo, meio e fim", 6,
        "Estruturar uma fala em abertura, desenvolvimento e conclusão.",
        "Toda fala fica mais fácil de seguir com três partes. Na abertura, você apresenta o tema e por que ele importa. No desenvolvimento, explica as ideias em ordem lógica, com exemplos. Na conclusão, retoma a ideia principal e diz o que o ouvinte pode fazer ou lembrar.",
        "Abertura: “Hoje vou mostrar como organizar a semana.” Desenvolvimento: três passos com um exemplo. Conclusão: “Então, comece listando as tarefas de segunda.”",
        listOf(
            q("Qual é a função da conclusão?", 3, "A conclusão reforça a mensagem e fecha o raciocínio.",
                "Apresentar um assunto novo", "Pedir desculpas pelo tempo", "Repetir tudo palavra por palavra", "Retomar a ideia principal e fechar a fala"),
            q("Onde é melhor apresentar o tema e sua importância?", 0, "A abertura prepara o ouvinte para o que virá.",
                "Na abertura", "Somente no final", "Em nenhum momento", "No meio, de forma escondida"),
            ord("Coloque as partes de uma fala na ordem em que aparecem.", "Primeiro você apresenta o tema, depois desenvolve as ideias com exemplos e, por fim, conclui retomando a ideia principal.",
                "Abertura: apresentar o tema e por que ele importa", "Desenvolvimento: explicar as ideias com exemplos", "Conclusão: retomar a ideia principal")
        ),
        "Monte, em tópicos, uma fala de 1 minuto sobre sua rotina com abertura, desenvolvimento e conclusão."
    ),
    Lesson(
        6, "UNIDADE 3 · VOZ", "Respiração e ritmo", 5,
        "Usar a respiração e as pausas para falar com calma e clareza.",
        "Respirar fundo antes de falar e respirar nos finais de frase evita falta de ar e aceleração. Pausas separam ideias e dão tempo ao ouvinte para processar o que foi dito. Falar rápido nem sempre passa domínio: variar o ritmo com naturalidade torna a mensagem mais compreensível.",
        "Faça uma pequena pausa depois da ideia principal e antes de um exemplo importante. Evite preencher todos os silêncios com “ééé” ou “tipo”: uma pausa curta soa mais firme.",
        listOf(
            q("Para que servem pausas bem colocadas?", 1, "Pausas separam ideias e facilitam a compreensão.",
                "Para esquecer o assunto", "Para separar ideias e facilitar a compreensão", "Para parecer artificial", "Para prolongar a fala sem motivo"),
            q("Quando é um bom momento para respirar?", 2, "Os finais de frase são pausas naturais e evitam a falta de ar.",
                "No meio das palavras", "Só quando faltar o ar", "Nos finais de frase", "Nunca; respirar atrapalha"),
            q("Em vez de preencher o silêncio com “ééé”, o melhor é…", 0, "Uma pausa curta transmite segurança e dá tempo para pensar.",
                "Fazer uma pausa curta", "Falar mais rápido", "Repetir a última frase", "Mudar de assunto")
        ),
        "Leia um parágrafo em voz alta marcando com uma barra (/) onde você fará pausas. Depois leia de novo respeitando as marcas."
    ),
    Lesson(
        7, "UNIDADE 3 · VOZ", "Dicção e articulação", 5,
        "Pronunciar as palavras com nitidez, sem exageros.",
        "Dicção é a clareza com que pronunciamos as palavras. Abrir bem a boca, articular as sílabas finais e não “engolir” palavras ajudam a ser entendido. Fale um pouco mais devagar que o habitual e treine trechos difíceis em voz alta. Sotaques regionais fazem parte da diversidade da língua: o objetivo é ser compreendido, não apagar seu jeito de falar.",
        "Treine em voz alta, começando devagar: “O rato roeu a roupa do rei de Roma.” Aumente o ritmo aos poucos, sem perder a nitidez.",
        listOf(
            q("O que é dicção?", 3, "Dicção é a nitidez na pronúncia das palavras.",
                "O volume da voz", "A velocidade da fala", "O sotaque", "A clareza na pronúncia das palavras"),
            q("Para treinar trava-línguas, o ideal é começar…", 1, "Começar devagar garante a precisão, e só depois se aumenta o ritmo.",
                "O mais rápido possível", "Devagar e acelerar aos poucos", "Em silêncio", "Sem repetir"),
            q("Ter sotaque regional significa falar errado?", 2, "Sotaques fazem parte da diversidade linguística; o foco é a clareza.",
                "Sim, sempre", "Sim, em apresentações", "Não; o foco é ser compreendido", "Sim, em ambientes profissionais")
        ),
        "Escolha um trava-língua, diga-o 3 vezes devagar e 3 vezes mais rápido, mantendo a nitidez."
    ),
    Lesson(
        8, "UNIDADE 3 · VOZ", "Entonação e ênfase", 5,
        "Variar a voz para destacar o que é importante.",
        "Uma voz sem variação cansa o ouvinte. Entonação é a melodia da fala: sobe, desce e muda de intensidade. Ênfase é destacar a palavra ou a ideia mais importante, falando um pouco mais forte, mais devagar ou fazendo uma pausa antes dela. Evite o exagero: a variação deve soar natural.",
        "Compare: “Eu NÃO disse que ele errou” e “Eu não disse que ELE errou”. Mudando a ênfase, muda o sentido da frase.",
        listOf(
            q("Qual é o efeito de falar sempre no mesmo tom?", 0, "A falta de variação tende a cansar e dispersar quem ouve.",
                "A fala pode ficar monótona e cansativa", "A fala fica mais profissional", "O público presta mais atenção", "Nenhum efeito"),
            q("Como destacar uma palavra importante?", 2, "Variar intensidade, ritmo ou usar uma pausa antes chama a atenção.",
                "Falando mais baixo sempre", "Repetindo-a dez vezes", "Falando-a com mais força ou fazendo uma pausa antes", "Falando mais rápido"),
            q("A ênfase pode mudar o sentido de uma frase?", 1, "Destacar palavras diferentes pode alterar o que a frase comunica.",
                "Não, nunca", "Sim, pode", "Só em textos escritos", "Só em outros idiomas")
        ),
        "Escolha uma frase e diga-a três vezes, destacando uma palavra diferente a cada vez. Note como o sentido muda."
    ),
    Lesson(
        9, "UNIDADE 4 · PRESENÇA", "Postura e contato visual", 5,
        "Usar o corpo e o olhar para reforçar a mensagem.",
        "O corpo também comunica. Mantenha os pés firmes, a coluna ereta sem rigidez e os braços livres para gesticular naturalmente. Olhe para as pessoas por alguns segundos, uma de cada vez, em vez de olhar para o chão ou o teto. Gestos devem apoiar a fala, não distraí-la.",
        "Ao dizer “são três pontos”, mostre três dedos. Ao terminar uma ideia, olhe para outra pessoa antes de seguir.",
        listOf(
            q("Qual é uma boa prática de contato visual?", 3, "Olhar por alguns segundos para pessoas diferentes cria conexão.",
                "Olhar só para o chão", "Olhar o tempo todo para o mesmo ponto", "Olhar para o teto", "Olhar para pessoas diferentes por alguns segundos"),
            q("Como devem ser os gestos?", 0, "Gestos naturais reforçam a fala; repetitivos ou exagerados distraem.",
                "Naturais e alinhados ao que se diz", "Constantes e rápidos", "Inexistentes", "Sempre amplos"),
            q("Uma postura adequada é…", 1, "Firme e relaxada transmite segurança sem parecer rígida.",
                "Curvada, para parecer humilde", "Firme e relaxada", "Totalmente imóvel", "Balançando o corpo o tempo todo")
        ),
        "Grave um vídeo curto no celular (apenas para você) ou use um espelho e observe sua postura e seus gestos durante 30 segundos de fala."
    ),
    Lesson(
        10, "UNIDADE 5 · CONTEÚDO", "Explique com exemplos", 6,
        "Tornar ideias abstratas mais fáceis de entender com exemplos e analogias.",
        "Um conceito abstrato fica mais compreensível quando acompanhado de uma situação concreta. Apresente primeiro a ideia e depois mostre como ela aparece na vida real. Uma analogia compara algo novo a algo conhecido, mas tem limites: use-a para facilitar a compreensão, não como prova.",
        "Conceito: planejamento. Exemplo: preparar uma lista de tarefas e definir horários antes de começar o dia.",
        listOf(
            q("Qual sequência ajuda mais a ensinar um conceito?", 1, "A definição apresenta a ideia; o exemplo mostra como ela funciona.",
                "Detalhes complexos e nenhuma definição", "Definição simples e exemplo relevante", "Só repetir a definição", "Mudar de assunto"),
            q("Uma analogia deve…", 2, "Analogias facilitam a compreensão, mas não provam conclusões.",
                "Substituir todos os fatos", "Ser complicada", "Ajudar a entender o conceito", "Provar qualquer conclusão"),
            q("Qual exemplo ilustra melhor “planejamento”?", 0, "O exemplo mostra a ação concreta ligada ao conceito.",
                "Fazer uma lista de tarefas antes do dia começar", "Esperar o dia passar", "Decidir tudo no último minuto", "Evitar compromissos")
        ),
        "Explique em voz alta um conceito do seu trabalho ou estudo usando um exemplo do dia a dia."
    ),
    Lesson(
        11, "UNIDADE 5 · CONTEÚDO", "Defenda uma ideia", 7,
        "Construir argumentos com razões e evidências, com respeito.",
        "Um argumento apresenta uma conclusão apoiada por razões. Para fortalecer sua fala, deixe claro o que você defende, por que defende e quais evidências sustentam a posição. Reconhecer objeções com respeito aumenta a credibilidade. Se você não tem certeza de algo, admita e verifique em vez de inventar. Persuadir de forma ética é convencer sem manipular nem enganar.",
        "“Devemos revisar o processo porque há retrabalho. Os registros mostram erros repetidos na mesma etapa. Revisar essa etapa pode reduzir os erros.”",
        listOf(
            q("O que fortalece um argumento?", 2, "Razões e evidências permitem avaliar se a conclusão é bem sustentada.",
                "Falar com agressividade", "Repetir a opinião várias vezes", "Apresentar razões e evidências relevantes", "Ignorar objeções"),
            q("Se você não tem certeza de uma informação, o melhor é…", 1, "Reconhecer limites protege a credibilidade.",
                "Inventar uma resposta convincente", "Admitir a incerteza e verificar", "Falar mais alto", "Mudar de assunto"),
            q("Persuadir de forma ética significa…", 3, "A persuasão ética usa razões verdadeiras e respeita a liberdade do outro.",
                "Esconder informações que atrapalham", "Pressionar a pessoa até concordar", "Exagerar os dados", "Convencer com razões verdadeiras, sem manipular")
        ),
        "Escolha uma opinião sua e a apresente em 3 frases: o que você defende, por que e uma evidência."
    ),
    Lesson(
        12, "UNIDADE 6 · PRÁTICA", "Improvise com a estrutura PREP", 6,
        "Responder perguntas de forma organizada sem decorar um discurso.",
        "A estrutura PREP ajuda a responder espontaneamente: Ponto, Razão, Exemplo e Ponto final. Você diz sua resposta, explica por quê, dá um exemplo e fecha repetindo a ideia. Se não entendeu uma pergunta, peça esclarecimento: é uma habilidade de comunicação, não uma fraqueza.",
        "Pergunta: “Planejar é importante?” Ponto: sim. Razão: organiza prioridades. Exemplo: uma lista de tarefas. Ponto final: por isso, planejar ajuda a trabalhar melhor.",
        listOf(
            q("Na estrutura PREP, o que vem depois do ponto principal?", 1, "PREP significa Ponto, Razão, Exemplo e Ponto final.",
                "Uma história sem relação", "A razão que sustenta a resposta", "Uma conclusão aleatória", "Uma nova pergunta"),
            q("Se não entendeu uma pergunta, você pode…", 0, "Pedir esclarecimento evita respostas fora do assunto.",
                "Pedir que a pessoa esclareça", "Fingir que entendeu", "Responder qualquer coisa", "Ficar em silêncio"),
            ord("Coloque os passos da estrutura PREP na ordem.", "PREP: Ponto, Razão, Exemplo e Ponto final.",
                "Ponto: dê sua resposta logo no início", "Razão: explique por que pensa assim", "Exemplo: ilustre com uma situação real", "Ponto final: repita a ideia para fechar")
        ),
        "Use PREP para responder: “Por que é importante organizar o próprio tempo?”. Fale por 1 minuto no treino de fala."
    ),
    Lesson(
        13, "UNIDADE 7 · NARRATIVA", "Storytelling: conte boas histórias", 6,
        "Usar histórias curtas para tornar sua mensagem mais memorável.",
        "Histórias ajudam as pessoas a entender e lembrar. Uma história simples tem um personagem em uma situação, um problema ou conflito, o que foi feito para resolvê-lo e um resultado. Use detalhes concretos, mas seja breve, e sempre ligue a história à mensagem que você quer transmitir.",
        "Em vez de dizer “atendimento rápido é importante”, conte: “Um cliente ligou três vezes sem resposta. Quando finalmente o atendemos, ele já tinha cancelado. Por isso respondemos agora em até uma hora.”",
        listOf(
            q("Por que usar histórias em uma fala?", 2, "Histórias criam conexão e ajudam o ouvinte a lembrar da ideia.",
                "Para ocupar o tempo da apresentação", "Para evitar explicar a ideia principal", "Para ajudar o ouvinte a se conectar e lembrar da mensagem", "Para parecer mais importante"),
            ord("Coloque os elementos de uma história simples na ordem.", "A sequência situação, problema, ação e resultado deixa a história fácil de acompanhar.",
                "Personagem e situação inicial", "Problema ou conflito", "O que foi feito para resolver", "Resultado e aprendizado"),
            q("Depois de contar uma história, o mais importante é…", 0, "Sem essa ligação, a história pode divertir, mas não reforça sua mensagem.",
                "Ligá-la à mensagem principal", "Começar outra história", "Pedir desculpas pelo tempo", "Mudar totalmente de assunto")
        ),
        "Conte em 1 minuto uma situação real que ensinou algo a você, seguindo as quatro partes da história."
    ),
    Lesson(
        14, "UNIDADE 8 · APRESENTAÇÕES", "Apresentações profissionais e acadêmicas", 6,
        "Planejar slides e falas que apoiam a mensagem e respeitam o tempo.",
        "Os slides apoiam a fala; eles não a substituem. Use uma ideia principal por slide, pouco texto e imagens ou gráficos que ajudem a entender. Não leia os slides: olhe para o público e use-os como guia. Ensaie com cronômetro para respeitar o tempo. Em apresentações acadêmicas, mostre o problema, como foi investigado, o que foi encontrado e a conclusão.",
        "Um slide com o título “Atrasos caíram 20%” e um gráfico simples costuma funcionar melhor do que um slide com dez linhas de texto.",
        listOf(
            q("Qual é a função dos slides?", 1, "Eles reforçam o que você diz; quem conduz a apresentação é você.",
                "Substituir a sua fala", "Apoiar e reforçar a fala", "Mostrar todo o texto para ser lido", "Preencher o tempo"),
            q("Qual é uma boa prática para os slides?", 3, "Uma ideia por slide com pouco texto facilita a compreensão.",
                "Colocar o máximo de texto possível", "Ler cada slide em voz alta, palavra por palavra", "Usar vários assuntos em cada slide", "Ter uma ideia principal por slide"),
            ord("Coloque em ordem a estrutura de uma apresentação acadêmica.", "Contextualizar o problema, explicar o método, mostrar os resultados e concluir ajuda a plateia a acompanhar a pesquisa.",
                "Tema e problema ou pergunta", "Método utilizado", "Resultados encontrados", "Conclusão e próximos passos")
        ),
        "Planeje três slides sobre um tema seu: um título, uma ideia por slide e uma frase de apoio para cada um."
    ),
    Lesson(
        15, "UNIDADE 9 · TRABALHO", "Entrevista de emprego", 6,
        "Apresentar-se e responder perguntas com segurança, clareza e honestidade.",
        "Antes da entrevista, pesquise a empresa e a vaga e prepare uma apresentação de cerca de um minuto: quem você é, o que já fez e o que busca. Ao responder perguntas sobre experiências, o método STAR ajuda: Situação, Tarefa, Ação e Resultado. Seja honesto, use exemplos reais e, ao final, faça perguntas sobre a vaga.",
        "“Em um projeto atrasado (situação), eu era responsável pelos prazos (tarefa). Reorganizei as entregas por prioridade (ação) e entregamos no dia combinado (resultado).”",
        listOf(
            q("Ao ouvir “fale sobre você”, o melhor é…", 1, "Um resumo breve e ligado à vaga mostra foco e prepara o assunto da conversa.",
                "Contar toda a sua vida em detalhes", "Fazer um resumo profissional breve ligado à vaga", "Dizer apenas o seu nome", "Perguntar por que a pergunta foi feita"),
            q("Ao ser perguntado sobre uma falha sua, o mais adequado é…", 0, "Reconhecer com um exemplo real e mostrar aprendizado transmite maturidade.",
                "Reconhecer com um exemplo real e explicar o que aprendeu", "Dizer que nunca errou", "Culpar colegas", "Inventar uma falha que pareça qualidade"),
            ord("Coloque o método STAR na ordem.", "STAR significa Situação, Tarefa, Ação e Resultado.",
                "Situação: o contexto", "Tarefa: o que era sua responsabilidade", "Ação: o que você fez", "Resultado: o que aconteceu")
        ),
        "Escreva e treine em voz alta uma apresentação pessoal de 1 minuto para uma vaga que você gostaria de ter."
    ),
    Lesson(
        16, "UNIDADE 9 · TRABALHO", "Reuniões e comunicação no trabalho", 5,
        "Comunicar-se de forma objetiva em reuniões, mensagens e atualizações.",
        "Uma reunião eficiente começa com objetivo e pauta definidos. Ao dar uma atualização, comece pelo resultado principal e só depois entre nos detalhes necessários. Escute os outros sem interromper e, ao final, resuma as decisões, os responsáveis e os prazos. Em mensagens escritas, vale a mesma regra: clareza primeiro.",
        "“Resultado: entregamos o relatório. Pendência: falta a revisão do financeiro. Próximo passo: envio até quinta.”",
        listOf(
            q("Uma reunião eficiente começa com…", 3, "Objetivo e pauta orientam a conversa e economizam tempo.",
                "Conversas livres sem horário", "Cada pessoa falando ao mesmo tempo", "Nenhuma preparação", "Objetivo e pauta definidos"),
            q("Ao dar uma atualização, o melhor é começar…", 1, "Quem ouve entende logo o essencial e decide se precisa de mais detalhes.",
                "Pelo histórico completo do projeto", "Pelo resultado principal", "Por justificativas", "Por assuntos de outras áreas"),
            q("Ao final da reunião, o ideal é…", 2, "O resumo evita mal-entendidos sobre quem faz o quê e até quando.",
                "Encerrar sem resumir", "Marcar outra reunião sem motivo", "Resumir decisões, responsáveis e prazos", "Deixar cada um interpretar como quiser")
        ),
        "Pense em uma atualização que você precisa dar esta semana e escreva em três linhas: resultado, pendência e próximo passo."
    ),
    Lesson(
        17, "UNIDADE 10 · RELAÇÕES", "Conversas difíceis e assertividade", 7,
        "Dizer o que precisa ser dito com clareza e respeito.",
        "Ser assertivo é expressar sua posição com clareza e respeito, sem agredir (agressivo) nem se calar (passivo). Em conversas difíceis, escolha um bom momento, descreva o fato sem acusar, explique o impacto, faça um pedido específico e ouça a resposta. Falar em primeira pessoa (“eu sinto”, “eu preciso”) reduz a defensividade.",
        "“Quando o relatório chega depois do prazo, eu fico sem tempo de revisar. Você consegue enviá-lo até quarta?”",
        listOf(
            q("Ser assertivo é…", 0, "Assertividade une firmeza e respeito.",
                "Expressar sua posição com clareza e respeito", "Impor a sua vontade", "Concordar sempre para evitar conflito", "Evitar falar do problema"),
            q("Qual frase é mais assertiva?", 2, "Ela descreve o fato, o impacto e faz um pedido específico, sem acusar.",
                "Você nunca entrega nada no prazo!", "Deixa pra lá, eu faço tudo sozinho.", "Quando o relatório atrasa, não consigo revisar. Pode enviar até quarta?", "Todo mundo já reclamou de você."),
            ord("Coloque em ordem os passos de uma conversa de feedback.", "Descrever o fato, explicar o impacto, fazer um pedido e ouvir permite uma conversa clara e respeitosa.",
                "Descrever o fato observado", "Explicar o impacto dele", "Fazer um pedido específico", "Ouvir a resposta da outra pessoa")
        ),
        "Escolha uma conversa que você está adiando e escreva o fato, o impacto e o pedido em uma frase cada."
    ),
    Lesson(
        18, "UNIDADE 11 · TÉCNICAS AVANÇADAS", "Perguntas do público e imprevistos", 6,
        "Lidar com perguntas difíceis, esquecimentos e problemas durante a fala.",
        "Ouça a pergunta inteira, faça uma pequena pausa e, se necessário, reformule-a para que todos entendam. Responda de forma breve. Se não souber, diga isso com tranquilidade e se comprometa a verificar depois. Se esquecer o que ia dizer, respire, faça uma pausa e retome a última ideia. Tenha um plano B para falhas técnicas, como um resumo impresso.",
        "“Boa pergunta. Não tenho esse número agora, mas confirmo e envio ainda hoje.”",
        listOf(
            q("Se você não souber a resposta a uma pergunta, o melhor é…", 1, "Reconhecer o limite e se comprometer a verificar protege sua credibilidade.",
                "Inventar uma resposta", "Admitir e se comprometer a verificar depois", "Ignorar a pergunta", "Mudar de assunto sem avisar"),
            q("Antes de responder uma pergunta do público, ajuda…", 3, "A pausa dá tempo para pensar, e a reformulação garante que todos entendam a pergunta.",
                "Responder antes de ela terminar", "Discordar logo de início", "Falar mais rápido", "Fazer uma pausa e, se preciso, reformular a pergunta"),
            q("Se você esquecer o que ia dizer, o melhor é…", 0, "Uma pausa curta e a retomada da última ideia costumam reorganizar o raciocínio.",
                "Respirar, pausar e retomar a última ideia", "Pedir desculpas várias vezes", "Encerrar a apresentação", "Ler tudo de uma vez")
        ),
        "Anote três perguntas difíceis que o seu público poderia fazer e treine responder cada uma em até 30 segundos."
    )
)

val speakingTopics: List<String> = listOf(
    "Explique por que organizar o tempo pode reduzir o estresse.",
    "Ensine alguém a realizar uma tarefa que você conhece bem.",
    "Defenda uma ideia que melhoraria o ambiente de trabalho ou de estudo.",
    "Explique um assunto difícil usando uma comparação simples.",
    "Conte um aprendizado importante que você teve no último ano.",
    "Apresente-se em 1 minuto como se estivesse numa entrevista de emprego.",
    "Explique por que ler ou estudar um pouco por dia faz diferença.",
    "Descreva um lugar que você gosta, de modo que o ouvinte o imagine.",
    "Dê três dicas para quem está começando em algo que você sabe fazer.",
    "Explique a diferença entre ouvir e escutar com atenção.",
    "Responda como em uma entrevista: conte uma situação em que você resolveu um problema.",
    "Dê uma atualização de 1 minuto sobre um projeto, começando pelo resultado.",
    "Conte uma história curta que ensine uma lição, com começo, conflito e resultado.",
    "Peça feedback a alguém de forma clara e respeitosa, como se estivesse falando com essa pessoa.",
    "Explique a um colega como você se prepara para uma apresentação importante."
)

val tongueTwisters: List<String> = listOf(
    "O rato roeu a roupa do rei de Roma.",
    "O peito do pé do Pedro é preto.",
    "Três pratos de trigo para três tigres tristes.",
    "A aranha arranha a rã; a rã arranha a aranha.",
    "Num ninho de mafagafos há sete mafagafinhos."
)

val achievementList: List<Achievement> = listOf(
    Achievement("first_lesson", "Primeiro passo", "Conclua sua primeira lição."),
    Achievement("five_lessons", "Pegando ritmo", "Conclua 5 lições."),
    Achievement("all_lessons", "Trilha completa", "Conclua todas as lições."),
    Achievement("perfect", "Acerto total", "Acerte todas as questões de uma lição."),
    Achievement("streak3", "3 dias seguidos", "Estude 3 dias em sequência."),
    Achievement("streak7", "Semana de foco", "Estude 7 dias em sequência."),
    Achievement("first_speech", "Primeira fala", "Conclua um treino de fala."),
    Achievement("five_speeches", "Voz em treino", "Conclua 5 treinos de fala."),
    Achievement("reviewer", "Aprendendo com erros", "Corrija 5 questões na revisão."),
    Achievement("fillers_aware", "Ouvido atento", "Conte os vícios de linguagem em 3 treinos gravados.")
)
