package br.com.falaup.app.data

enum class QuestionKind { CHOICE, ORDER }

/**
 * CHOICE: escolha uma alternativa; [correct] é o índice certo.
 * ORDER: [options] já estão na ORDEM CORRETA; a tela as embaralha e o usuário as toca na sequência certa.
 */
data class Question(
    val prompt: String,
    val options: List<String>,
    val correct: Int,
    val explanation: String,
    val kind: QuestionKind = QuestionKind.CHOICE
)

/** Resposta como texto: CHOICE = "2"; ORDER = "1,0,2" (índices originais na ordem tocada). */
fun answerTokens(answer: String): List<Int> = answer.split(",").mapNotNull { it.trim().toIntOrNull() }

fun Question.isComplete(answer: String): Boolean = when (kind) {
    QuestionKind.CHOICE -> answer.trim().toIntOrNull() != null
    QuestionKind.ORDER -> answerTokens(answer).size == options.size
}

fun Question.isCorrect(answer: String): Boolean = when (kind) {
    QuestionKind.CHOICE -> answer.trim().toIntOrNull() == correct
    QuestionKind.ORDER -> answerTokens(answer) == options.indices.toList()
}

/** Ordem de exibição (fixa e nunca igual à correta) dos itens de uma questão ORDER. */
fun Question.displayOrder(): List<Int> {
    val base = options.indices.shuffled(java.util.Random(prompt.hashCode().toLong()))
    return if (base == options.indices.toList() && base.size > 1) base.drop(1) + base.first() else base
}

data class Lesson(
    val id: Int,
    val unit: String,
    val title: String,
    val minutes: Int,
    val objective: String,
    val intro: String,
    val example: String,
    val questions: List<Question>,
    val challenge: String
)

data class Achievement(
    val id: String,
    val title: String,
    val description: String
)

data class SpeakingSession(
    val timestamp: Long,
    val topic: String,
    val plannedSeconds: Int,
    val actualSeconds: Int,
    /** Autoavaliação: quantos dos 4 critérios o usuário marcou como cumpridos (0..4). */
    val criteriaMet: Int,
    /** Vícios de linguagem (né, tipo, ééé) contados ao ouvir a gravação; -1 = não contou. */
    val fillerCount: Int = -1,
    /** Nome do arquivo de áudio salvo no aparelho (ou null se não gravou). */
    val audioFile: String?
)

/** Estado completo salvo no aparelho. */
data class ProgressState(
    val xp: Int = 0,
    /** Mapa idDaLição -> melhor número de acertos. Presente = lição concluída. */
    val completed: Map<Int, Int> = emptyMap(),
    /** Perguntas erradas ainda não revisadas, no formato "idLição:índice". */
    val wrong: Set<String> = emptySet(),
    val streak: Int = 0,
    val longestStreak: Int = 0,
    /** Último dia de estudo (ISO yyyy-MM-dd) ou vazio. */
    val lastStudyDate: String = "",
    val dailyXp: Int = 0,
    val dailyXpDate: String = "",
    val dailyGoal: Int = 20,
    val reviewedCorrect: Int = 0,
    val sessions: List<SpeakingSession> = emptyList(),
    val achievements: Set<String> = emptySet(),
    /** Quantas sessões de fala já deram XP em cada dia (para evitar abuso). */
    val speakingXpDate: String = "",
    val speakingXpCount: Int = 0,
    val onboardingDone: Boolean = false,
    val goalPurpose: String = "Falar com mais confiança",
    val darkMode: Boolean = false,
    val largeText: Boolean = false,
    val reminderEnabled: Boolean = false,
    val reminderHour: Int = 19,
    val reminderMinute: Int = 0
)
