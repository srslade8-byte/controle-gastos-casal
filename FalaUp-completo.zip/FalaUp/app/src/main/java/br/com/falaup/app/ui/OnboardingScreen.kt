package br.com.falaup.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun OnboardingScreen(onFinish: (String, Int) -> Unit) {
    var purpose by remember { mutableStateOf("Falar em público") }
    var goal by remember { mutableIntStateOf(20) }
    Surface(color = FalaColors.Background, modifier = Modifier.fillMaxSize()) {
        CenteredContent(Modifier.padding(24.dp)) {
            Spacer(Modifier.height(42.dp))
            Eyebrow("FALAUP")
            Spacer(Modifier.height(12.dp))
            ScreenTitle("Sua voz.\nSua evolução.")
            Spacer(Modifier.height(12.dp))
            Text("Vamos adaptar seu primeiro treino. Nada é enviado para a internet.", color = FalaColors.Muted, fontSize = 16.sp, lineHeight = 23.sp)
            Spacer(Modifier.height(28.dp))
            Text("Qual é o seu objetivo agora?", style = MaterialTheme.typography.titleLarge, color = FalaColors.Navy)
            Spacer(Modifier.height(10.dp))
            listOf("Falar em público", "Me preparar para entrevistas", "Me comunicar melhor no trabalho").forEach { item ->
                FilterChip(selected = purpose == item, onClick = { purpose = item }, label = { Text(item) }, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
            }
            Spacer(Modifier.height(16.dp))
            Text("Quanto você quer praticar por dia?", style = MaterialTheme.typography.titleLarge, color = FalaColors.Navy)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(20, 40, 60).forEach { value -> FilterChip(selected = goal == value, onClick = { goal = value }, label = { Text("$value XP") }) }
            }
            Spacer(Modifier.weight(1f))
            BigButton("Começar minha jornada") { onFinish(purpose, goal) }
        }
    }
}
