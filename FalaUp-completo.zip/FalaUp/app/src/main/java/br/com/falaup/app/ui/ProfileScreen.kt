package br.com.falaup.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.falaup.app.audio.AudioPlayer
import br.com.falaup.app.data.ProgressState
import br.com.falaup.app.data.Rules
import br.com.falaup.app.data.SpeakingSession
import br.com.falaup.app.data.achievementList
import br.com.falaup.app.data.lessons
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

@Composable
fun ProfileScreen(
    s: ProgressState,
    padding: PaddingValues,
    onGoal: (Int) -> Unit,
    onDeleteSession: (Long) -> Unit,
    onReset: () -> Unit,
    onDarkMode: (Boolean) -> Unit,
    onLargeText: (Boolean) -> Unit,
    onReminder: (Boolean, Int, Int) -> Unit,
    onExport: () -> Unit,
    onImport: () -> Unit
) {
    val context = LocalContext.current
    val player = remember { AudioPlayer(context) }
    var playingFile by remember { mutableStateOf<String?>(null) }
    var confirmReset by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { player.stop() } }

    val today = LocalDate.now()
    val level = Rules.level(s.xp)
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")) }

    CenteredContent(Modifier.padding(padding)) {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            item {
                Spacer(Modifier.height(22.dp))
                Eyebrow("SEU PERFIL")
                ScreenTitle("Sua evolução")
                Spacer(Modifier.height(16.dp))
                WhiteCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        IconBubble(Icons.Default.Person, size = 80)
                        Spacer(Modifier.height(10.dp))
                        Text(Rules.levelTitle(level), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = FalaColors.Navy)
                        Text("Nível $level", color = FalaColors.Blue, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { Rules.xpInLevel(s.xp) / Rules.XP_PER_LEVEL.toFloat() },
                            modifier = Modifier.fillMaxWidth().height(8.dp),
                            color = FalaColors.Blue, trackColor = FalaColors.Track
                        )
                        Text("${Rules.xpInLevel(s.xp)} / ${Rules.XP_PER_LEVEL} XP para o próximo nível", color = FalaColors.Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(16.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            Stat("${s.xp}", "XP")
                            Stat("${s.completed.size}/${lessons.size}", "Lições")
                            Stat("${Rules.currentStreak(s, today)}", "Sequência")
                            Stat("${s.sessions.size}", "Treinos")
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("Maior sequência: ${s.longestStreak} dia(s)", color = FalaColors.Muted, fontSize = 12.sp)
                    }
                }

                Spacer(Modifier.height(18.dp))
                Text("Meta diária", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = FalaColors.Navy)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(20, 40, 60).forEach { g ->
                        FilterChip(selected = s.dailyGoal == g, onClick = { onGoal(g) }, label = { Text("$g XP") })
                    }
                }

                Spacer(Modifier.height(18.dp))
                Text("Preferências", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = FalaColors.Navy)
                WhiteCard(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    PreferenceRow("Modo escuro", "Conforto visual à noite", s.darkMode, onDarkMode)
                    PreferenceRow("Fonte maior", "Mais legibilidade", s.largeText, onLargeText)
                    PreferenceRow("Lembrete diário", "Local e opcional, sem coletar dados", s.reminderEnabled) { enabled -> onReminder(enabled, s.reminderHour, s.reminderMinute) }
                    if (s.reminderEnabled) {
                        Text("Horário: %02d:%02d".format(s.reminderHour, s.reminderMinute), color = FalaColors.Muted, fontSize = 13.sp)
                        TextButton(onClick = { onReminder(true, if (s.reminderHour == 19) 20 else 19, s.reminderMinute) }) { Text("Alternar horário") }
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text("Evolução recente", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = FalaColors.Navy)
                WhiteCard(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Text("Duração dos últimos treinos", color = FalaColors.Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
                        (if (s.sessions.isEmpty()) listOf(0) else s.sessions.take(7).reversed().map { it.actualSeconds }).forEach { seconds ->
                            Box(Modifier.width(24.dp).height((seconds.coerceIn(10, 120) / 4).dp), contentAlignment = Alignment.BottomCenter) {
                                Surface(Modifier.fillMaxSize(), color = FalaColors.Blue, shape = androidx.compose.foundation.shape.RoundedCornerShape(6.dp)) {}
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("${s.sessions.size} treinos · ${s.sessions.sumOf { it.actualSeconds }} s praticados", color = FalaColors.Muted, fontSize = 12.sp)
                }
                OutlinedButton(onClick = onExport, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Text("Exportar meu progresso") }
                OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) { Text("Importar backup") }

                Spacer(Modifier.height(18.dp))
                Text("Conquistas", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = FalaColors.Navy)
                Spacer(Modifier.height(8.dp))
            }
            items(achievementList) { a ->
                val unlocked = a.id in s.achievements
                WhiteCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (unlocked) IconBubble(Icons.Default.EmojiEvents, FalaColors.Green, FalaColors.GreenSoft, 40)
                        else IconBubble(Icons.Default.Lock, FalaColors.Muted, androidx.compose.ui.graphics.Color(0xFFEEF1F7), 40)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(a.title, fontWeight = FontWeight.Bold, color = if (unlocked) FalaColors.Navy else FalaColors.Muted)
                            Text(a.description, color = FalaColors.Muted, fontSize = 13.sp)
                        }
                    }
                }
            }
            item {
                Spacer(Modifier.height(14.dp))
                Text("Histórico de treinos", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = FalaColors.Navy)
                Spacer(Modifier.height(8.dp))
                if (s.sessions.isEmpty()) {
                    Text("Seus treinos de fala aparecerão aqui.", color = FalaColors.Muted)
                }
            }
            items(s.sessions, key = { it.timestamp }) { session ->
                SessionRow(
                    session, dateFormat.format(Date(session.timestamp)),
                    playing = playingFile != null && playingFile == session.audioFile,
                    onPlay = {
                        val f = session.audioFile
                        if (f != null) {
                            if (playingFile == f) { player.stop(); playingFile = null }
                            else if (player.play(f) { playingFile = null }) playingFile = f
                        }
                    },
                    onDelete = {
                        if (playingFile == session.audioFile) { player.stop(); playingFile = null }
                        onDeleteSession(session.timestamp)
                    }
                )
            }
            item {
                Spacer(Modifier.height(20.dp))
                WhiteCard(Modifier.fillMaxWidth()) {
                    Text("Privacidade", fontWeight = FontWeight.Bold, color = FalaColors.Navy)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Seu progresso e suas gravações ficam apenas neste aparelho. O FalaUp não envia dados para servidores e não usa publicidade.",
                        color = FalaColors.Muted, fontSize = 13.sp, lineHeight = 19.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { confirmReset = true }) { Text("Apagar todo o meu progresso") }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Apagar tudo?") },
            text = { Text("Isso remove XP, lições concluídas, histórico e gravações deste aparelho. Não dá para desfazer.") },
            confirmButton = {
                TextButton(onClick = { player.stop(); playingFile = null; confirmReset = false; onReset() }) { Text("Apagar") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun PreferenceRow(label: String, description: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, fontWeight = FontWeight.SemiBold, color = FalaColors.Navy)
            Text(description, color = FalaColors.Muted, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = FalaColors.Navy)
        Text(label, color = FalaColors.Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SessionRow(
    session: SpeakingSession, dateText: String, playing: Boolean,
    onPlay: () -> Unit, onDelete: () -> Unit
) {
    WhiteCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(session.topic, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 19.sp)
                Spacer(Modifier.height(2.dp))
                Text(
                    "$dateText · ${formatTime(session.actualSeconds)} · ${session.criteriaMet}/${speechCriteria.size} critérios" +
                        (if (session.fillerCount >= 0) " · ${session.fillerCount} vícios" else ""),
                    color = FalaColors.Muted, fontSize = 12.sp
                )
            }
            if (session.audioFile != null) {
                IconButton(onClick = onPlay) {
                    Icon(if (playing) Icons.Default.Stop else Icons.Default.PlayArrow, if (playing) "Parar" else "Ouvir gravação", tint = FalaColors.Blue)
                }
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Apagar treino", tint = FalaColors.Muted) }
        }
    }
}
