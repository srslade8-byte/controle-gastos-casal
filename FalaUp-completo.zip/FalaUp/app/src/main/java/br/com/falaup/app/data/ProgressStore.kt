package br.com.falaup.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Salva o progresso no aparelho (SharedPreferences, em JSON).
 * Escolha deliberada: o volume de dados é pequeno (alguns KB) e não há consultas complexas,
 * então Room traria complexidade sem benefício nesta fase.
 */
class ProgressStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("falaup_state_v2", Context.MODE_PRIVATE)

    fun load(): ProgressState {
        val raw = prefs.getString(KEY, null) ?: return ProgressState()
        return try {
            fromJson(JSONObject(raw))
        } catch (e: Exception) {
            ProgressState()
        }
    }

    fun save(state: ProgressState) {
        prefs.edit().putString(KEY, toJson(state).toString()).apply()
    }

    companion object {
        private const val KEY = "state"

        internal fun toJson(s: ProgressState): JSONObject = JSONObject().apply {
            put("xp", s.xp)
            put("completed", JSONObject().also { o -> s.completed.forEach { (k, v) -> o.put(k.toString(), v) } })
            put("wrong", JSONArray(s.wrong.toList()))
            put("streak", s.streak)
            put("longestStreak", s.longestStreak)
            put("lastStudyDate", s.lastStudyDate)
            put("dailyXp", s.dailyXp)
            put("dailyXpDate", s.dailyXpDate)
            put("dailyGoal", s.dailyGoal)
            put("reviewedCorrect", s.reviewedCorrect)
            put("achievements", JSONArray(s.achievements.toList()))
            put("speakingXpDate", s.speakingXpDate)
            put("speakingXpCount", s.speakingXpCount)
            put("onboardingDone", s.onboardingDone)
            put("goalPurpose", s.goalPurpose)
            put("darkMode", s.darkMode)
            put("largeText", s.largeText)
            put("reminderEnabled", s.reminderEnabled)
            put("reminderHour", s.reminderHour)
            put("reminderMinute", s.reminderMinute)
            put("sessions", JSONArray().also { arr ->
                s.sessions.forEach { x ->
                    arr.put(JSONObject().apply {
                        put("timestamp", x.timestamp)
                        put("topic", x.topic)
                        put("planned", x.plannedSeconds)
                        put("actual", x.actualSeconds)
                        put("criteria", x.criteriaMet)
                        put("fillers", x.fillerCount)
                        put("audio", x.audioFile ?: JSONObject.NULL)
                    })
                }
            })
        }

        internal fun fromJson(o: JSONObject): ProgressState {
            val completed = mutableMapOf<Int, Int>()
            o.optJSONObject("completed")?.let { c ->
                c.keys().forEach { k -> k.toIntOrNull()?.let { id -> completed[id] = c.optInt(k) } }
            }
            val wrong = mutableSetOf<String>()
            o.optJSONArray("wrong")?.let { a -> for (i in 0 until a.length()) wrong.add(a.getString(i)) }
            val ach = mutableSetOf<String>()
            o.optJSONArray("achievements")?.let { a -> for (i in 0 until a.length()) ach.add(a.getString(i)) }
            val sessions = mutableListOf<SpeakingSession>()
            o.optJSONArray("sessions")?.let { a ->
                for (i in 0 until a.length()) {
                    val x = a.getJSONObject(i)
                    sessions.add(
                        SpeakingSession(
                            timestamp = x.optLong("timestamp"),
                            topic = x.optString("topic"),
                            plannedSeconds = x.optInt("planned"),
                            actualSeconds = x.optInt("actual"),
                            criteriaMet = x.optInt("criteria"),
                            fillerCount = x.optInt("fillers", -1),
                            audioFile = if (x.isNull("audio")) null else x.optString("audio")
                        )
                    )
                }
            }
            return ProgressState(
                xp = o.optInt("xp"),
                completed = completed,
                wrong = wrong,
                streak = o.optInt("streak"),
                longestStreak = o.optInt("longestStreak"),
                lastStudyDate = o.optString("lastStudyDate"),
                dailyXp = o.optInt("dailyXp"),
                dailyXpDate = o.optString("dailyXpDate"),
                dailyGoal = o.optInt("dailyGoal", 20),
                reviewedCorrect = o.optInt("reviewedCorrect"),
                sessions = sessions,
                achievements = ach,
                speakingXpDate = o.optString("speakingXpDate"),
                speakingXpCount = o.optInt("speakingXpCount"),
                onboardingDone = o.optBoolean("onboardingDone", false),
                goalPurpose = o.optString("goalPurpose", "Falar com mais confiança"),
                darkMode = o.optBoolean("darkMode", false),
                largeText = o.optBoolean("largeText", false),
                reminderEnabled = o.optBoolean("reminderEnabled", false),
                reminderHour = o.optInt("reminderHour", 19),
                reminderMinute = o.optInt("reminderMinute", 0)
            )
        }
    }
}
