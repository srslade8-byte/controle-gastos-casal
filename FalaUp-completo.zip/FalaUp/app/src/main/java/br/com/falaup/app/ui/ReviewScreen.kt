package br.com.falaup.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.falaup.app.data.Question
import br.com.falaup.app.data.isComplete
import br.com.falaup.app.data.isCorrect
import br.com.falaup.app.data.lessons

private data class ReviewItem(val key: String, val lessonTitle: String, val question: Question)

private fun buildItems(keys: List<String>): List<ReviewItem> = keys.mapNotNull { key ->
    val parts = key.split(":")
    val lesson = lessons.firstOrNull { it.id == parts.getOrNull(0)?.toIntOrNull() } ?: return@mapNotNull null
    val q = lesson.questions.getOrNull(parts.getOrNull(1)?.toIntOrNull() ?: -1) ?: return@mapNotNull null
    ReviewItem(key, lesson.title, q)
}

/** Revisão das questões erradas. Acertar uma questão a remove da lista e dá XP uma única vez. */
@Composable
fun ReviewScreen(wrongKeys: Set<String>, onExit: () -> Unit, onAnswer: (key: String, correct: Boolean) -> Unit) {
    // Congela a lista no início da sessão para a ordem não mudar durante a revisão.
    val snapshot = rememberSaveable { wrongKeys.sorted() }
    val items = remember(snapshot) { buildItems(snapshot) }
    var index by rememberSaveable { mutableIntStateOf(0) }
    var answer by rememberSaveable { mutableStateOf("") }
    var checked by rememberSaveable { mutableStateOf(false) }
    var hits by rememberSaveable { mutableIntStateOf(0) }

    CenteredContent(Modifier.statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onExit) { Icon(Icons.Default.Close, "Sair da revisão", tint = FalaColors.Navy) }
            Text("REVISÃO", color = FalaColors.Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Spacer(Modifier.height(12.dp))

        if (items.isEmpty() || index >= items.size) {
            Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(if (items.isEmpty()) "Nada para revisar" else "Revisão concluída!", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = FalaColors.Navy)
                Spacer(Modifier.height(8.dp))
                if (items.isNotEmpty()) {
                    Text("$hits de ${items.size} corrigidas · +${hits * br.com.falaup.app.data.Rules.REVIEW_XP} XP", color = FalaColors.Muted)
                } else {
                    Text("Você não tem questões erradas pendentes.", color = FalaColors.Muted)
                }
            }
            BigButton("Voltar", onClick = onExit)
        } else {
            val item = items[index]
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Text("Lição: ${item.lessonTitle} · ${index + 1} de ${items.size}", color = FalaColors.Muted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                QuestionView(item.question, answer, checked) { answer = it }
                Spacer(Modifier.height(12.dp))
            }
            Spacer(Modifier.height(10.dp))
            BigButton(
                text = when {
                    !checked -> "Conferir resposta"
                    index + 1 < items.size -> "Próxima"
                    else -> "Concluir revisão"
                },
                enabled = item.question.isComplete(answer)
            ) {
                if (!checked) {
                    checked = true
                    val ok = item.question.isCorrect(answer)
                    if (ok) hits++
                    onAnswer(item.key, ok)
                } else {
                    index++
                    answer = ""
                    checked = false
                }
            }
        }
    }
}
