package br.com.falaup.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import br.com.falaup.app.data.lessons
import br.com.falaup.app.ui.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { FalaUpApp() }
    }
}

private enum class Tab(val label: String, val icon: ImageVector) {
    Home("Início", Icons.Default.Home), Path("Trilha", Icons.Default.Route),
    Practice("Prática", Icons.Default.Mic), Profile("Perfil", Icons.Default.Person)
}
private enum class Screen { Tabs, Lesson, Review, Speaking }

@Composable
fun FalaUpApp(vm: FalaUpViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val message by vm.message.collectAsState()
    var tab by rememberSaveable { mutableStateOf(Tab.Home) }
    var route by rememberSaveable { mutableStateOf(Screen.Tabs) }
    var lessonId by rememberSaveable { mutableIntStateOf(lessons.first().id) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { runCatching { context.contentResolver.openInputStream(it)?.bufferedReader()?.use { reader -> vm.importProgress(reader.readText()) } } }
    }

    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); vm.consumeMessage() } }
    LaunchedEffect(state.reminderEnabled) {
        if (state.reminderEnabled && Build.VERSION.SDK_INT >= 33 &&
            androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            (context as? ComponentActivity)?.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 921)
        }
    }
    BackHandler(enabled = route != Screen.Tabs) { route = Screen.Tabs }

    FalaUpTheme(dark = state.darkMode, largeText = state.largeText) {
        if (!state.onboardingDone) {
            OnboardingScreen(onFinish = vm::finishOnboarding)
            return@FalaUpTheme
        }
        fun openLesson(id: Int) { lessonId = id; route = Screen.Lesson }
        when (route) {
            Screen.Lesson -> {
                val lesson = lessons.firstOrNull { it.id == lessonId } ?: lessons.first()
                LessonScreen(lesson, onExit = { route = Screen.Tabs },
                    onFinish = { correct, missed -> vm.finishLesson(lesson, correct, missed) },
                    onPractice = { route = Screen.Speaking })
            }
            Screen.Review -> ReviewScreen(state.wrong, { route = Screen.Tabs }) { key, ok -> vm.answerReview(key, ok) }
            Screen.Speaking -> SpeakingScreen({ route = Screen.Tabs }) { vm.addSession(it) }
            Screen.Tabs -> Scaffold(
                containerColor = FalaColors.Background,
                snackbarHost = { SnackbarHost(snackbar) },
                bottomBar = { NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    Tab.values().forEach { t -> NavigationBarItem(tab == t, { tab = t }, { Icon(t.icon, t.label) }, label = { Text(t.label) }) }
                } }
            ) { padding: PaddingValues ->
                when (tab) {
                    Tab.Home -> HomeScreen(state, padding, ::openLesson, { route = Screen.Speaking }, { route = Screen.Review })
                    Tab.Path -> PathScreen(state, padding, ::openLesson) { scope.launch { snackbar.showSnackbar("Conclua a lição anterior para liberar esta.") } }
                    Tab.Practice -> PracticeScreen(padding, state.sessions.size) { route = Screen.Speaking }
                    Tab.Profile -> ProfileScreen(state, padding,
                        onGoal = vm::setDailyGoal,
                        onDeleteSession = vm::deleteSession,
                        onReset = vm::resetAll,
                        onDarkMode = vm::setDarkMode,
                        onLargeText = vm::setLargeText,
                        onReminder = vm::setReminder,
                        onExport = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "application/json"
                                putExtra(Intent.EXTRA_SUBJECT, "Meu progresso no FalaUp")
                                putExtra(Intent.EXTRA_TEXT, vm.exportProgress())
                            }
                            context.startActivity(Intent.createChooser(send, "Exportar progresso"))
                        },
                        onImport = { importLauncher.launch(arrayOf("application/json", "text/plain")) })
                }
            }
        }
    }
}
