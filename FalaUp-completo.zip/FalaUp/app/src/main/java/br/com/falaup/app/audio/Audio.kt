package br.com.falaup.app.audio

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import java.io.File

fun recordingsDir(context: Context): File =
    File(context.filesDir, "recordings").apply { mkdirs() }

/** Grava a voz do usuário em um arquivo privado do app. O áudio nunca sai do aparelho. */
class VoiceRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var file: File? = null

    fun start(): Boolean {
        return try {
            val f = File(recordingsDir(context), "fala_${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION") MediaRecorder()
            }
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(96_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            file = f
            true
        } catch (e: Exception) {
            cancel()
            false
        }
    }

    /** Encerra e devolve o nome do arquivo, ou null se a gravação falhou. */
    fun stop(): String? {
        val r = recorder ?: return null
        val f = file
        recorder = null
        file = null
        return try {
            r.stop()
            r.release()
            f?.name
        } catch (e: RuntimeException) {
            // Acontece se a gravação foi curta demais para gerar áudio.
            try { r.release() } catch (_: Exception) {}
            f?.delete()
            null
        }
    }

    /** Interrompe e descarta a gravação em andamento. */
    fun cancel() {
        val r = recorder
        val f = file
        recorder = null
        file = null
        if (r != null) {
            try { r.stop() } catch (_: Exception) {}
            try { r.release() } catch (_: Exception) {}
        }
        f?.delete()
    }
}

class AudioPlayer(private val context: Context) {
    private var player: MediaPlayer? = null

    fun play(fileName: String, onDone: () -> Unit): Boolean {
        stop()
        return try {
            val f = File(recordingsDir(context), fileName)
            if (!f.exists()) return false
            val p = MediaPlayer()
            p.setDataSource(f.absolutePath)
            p.setOnCompletionListener { stop(); onDone() }
            p.prepare()
            p.start()
            player = p
            true
        } catch (e: Exception) {
            stop()
            false
        }
    }

    fun stop() {
        player?.let {
            try { it.stop() } catch (_: Exception) {}
            try { it.release() } catch (_: Exception) {}
        }
        player = null
    }
}
