package br.com.falaup.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import br.com.falaup.app.audio.AudioPlayer
import br.com.falaup.app.audio.VoiceRecorder
import br.com.falaup.app.audio.recordingsDir
import br.com.falaup.app.data.SpeakingSession
import br.com.falaup.app.data.speakingTopics
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun SpeakingScreen(onExit: () -> Unit, onSave: (SpeakingSession) -> Int) {
    val context = LocalContext.current
    val recorder = remember { VoiceRecorder(context) }
    val player = remember { AudioPlayer(context) }

    var topicIndex by rememberSaveable { mutableIntStateOf((speakingTopics.indices).random()) }
    var duration by rememberSaveable { mutableIntStateOf(60) }
    var wantRecord by rememberSaveable { mutableStateOf(true) }
    var phase by rememberSaveable { mutableIntStateOf(0) } // 0 preparar, 1 falando, 2 avaliar
    var elapsed by rememberSaveable { mutableIntStateOf(0) }
    var audioName by rememberSaveable { mutableStateOf<String?>(null) }
    var criteriaMask by rememberSaveable { mutableIntStateOf(0) }
    var fillers by rememberSaveable { mutableIntStateOf(0) }
    var fillersCounted by rememberSaveable { mutableStateOf(false) }
    var recordFailed by rememberSaveable { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var startedAt by rememberSaveable { mutableLongStateOf(0L) }
    var saved by rememberSaveable { mutableStateOf(false) }
    var xpGained by rememberSaveable { mutableIntStateOf(-1) }
    var guided by rememberSaveable { mutableStateOf(false) }
    var teleprompter by rememberSaveable { mutableStateOf(false) }
    var warmupSeconds by rememberSaveable { mutableIntStateOf(0) }
    var warmupDone by rememberSaveable { mutableStateOf(false) }

    val guidedScript = when {
        speakingTopics[topicIndex].contains("entrevista", ignoreCase = true) -> "Comece se apresentando. Conte uma situação concreta, explique o que você fez e finalize com o resultado."
        speakingTopics[topicIndex].contains("trabalho", ignoreCase = true) -> "Apresente a ideia principal. Dê dois motivos. Use um exemplo. Termine com um próximo passo claro."
        else -> "Apresente o tema em uma frase. Desenvolva com dois pontos. Faça uma pausa. Conclua retomando a mensagem principal."
    }

    // Ao sair da tela: encerra gravação/reprodução e apaga áudio que não foi salvo.
    val savedState = rememberUpdatedState(saved)
    val audioState = rememberUpdatedState(audioName)
    DisposableEffect(Unit) {
        onDispose {
            recorder.cancel()
            player.stop()
            val name = audioState.value
            if (!savedState.value && name != null) {
                try { File(recordingsDir(context), name).delete() } catch (_: Exception) {}
            }
        }
    }

    fun finish() {
        val actual = ((SystemClock.elapsedRealtime() - startedAt) / 1000).toInt().coerceIn(0, duration)
        elapsed = actual
        val name = recorder.stop()
        audioName = name
        recordFailed = wantRecord && name == null
        phase = 2
    }

    fun begin() {
        recordFailed = false
        if (wantRecord && !recorder.start()) {
            recordFailed = true
        }
        startedAt = SystemClock.elapsedRealtime()
        elapsed = 0
        phase = 1
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) begin() else wantRecord = false
    }

    fun onStartClick() {
        val has = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (wantRecord && !has) permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) else begin()
    }

    LaunchedEffect(phase) {
        if (phase == 1) {
            while (true) {
                val sec = ((SystemClock.elapsedRealtime() - startedAt) / 1000).toInt()
                elapsed = sec.coerceAtMost(duration)
                if (sec >= duration) { finish(); break }
                delay(250)
            }
        }
    }

    LaunchedEffect(warmupSeconds) {
        if (warmupSeconds > 0) {
            delay(1000)
            warmupSeconds -= 1
            if (warmupSeconds == 0) warmupDone = true
        }
    }

    CenteredContent(Modifier.statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onExit) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = FalaColors.Navy) }
            Eyebrow("TREINO DE FALA")
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            when (phase) {
                0 -> {
                    Spacer(Modifier.height(8.dp))
                    ScreenTitle("Fale com clareza.")
                    Spacer(Modifier.height(14.dp))
                    WhiteCard(Modifier.fillMaxWidth()) {
                        Eyebrow("SEU TEMA")
                        Spacer(Modifier.height(8.dp))
                        Text(speakingTopics[topicIndex], fontSize = 20.sp, fontWeight = FontWeight.SemiBold, lineHeight = 27.sp)
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(onClick = {
                            var next = speakingTopics.indices.random()
                            if (next == topicIndex) next = (next + 1) % speakingTopics.size
                            topicIndex = next
                        }) { Text("Sortear outro tema") }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Duração", fontWeight = FontWeight.Bold, color = FalaColors.Navy)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(30 to "30 s", 60 to "1 min", 120 to "2 min").forEach { (sec, label) ->
                            FilterChip(selected = duration == sec, onClick = { duration = sec }, label = { Text(label) })
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    WhiteCard(Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Gravar minha voz", fontWeight = FontWeight.Bold)
                                Text(
                                    "Usa o microfone só durante o treino. O áudio fica salvo apenas neste aparelho e você pode apagá-lo quando quiser.",
                                    color = FalaColors.Muted, fontSize = 12.sp, lineHeight = 17.sp
                                )
                            }
                            Spacer(Modifier.width(10.dp))
                            Switch(checked = wantRecord, onCheckedChange = { wantRecord = it })
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    WhiteCard(Modifier.fillMaxWidth()) {
                        Text("Preparação guiada", fontWeight = FontWeight.Bold, color = FalaColors.Navy)
                        Text("Aqueça a voz e escolha como quer treinar.", color = FalaColors.Muted, fontSize = 12.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("Treino com roteiro"); Text("Ideia → motivo → exemplo → conclusão", color = FalaColors.Muted, fontSize = 12.sp) }
                            Switch(checked = guided, onCheckedChange = { guided = it })
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("Teleprompter"); Text("Ver o roteiro durante a gravação", color = FalaColors.Muted, fontSize = 12.sp) }
                            Switch(checked = teleprompter, onCheckedChange = { teleprompter = it })
                        }
                        if (!warmupDone) {
                            TextButton(onClick = { if (warmupSeconds == 0) warmupSeconds = 120 }) {
                                Text(if (warmupSeconds > 0) "Aquecendo: ${formatTime(warmupSeconds)}" else "Iniciar aquecimento de 2 min")
                            }
                        } else Text("Aquecimento concluído", color = FalaColors.Green, fontWeight = FontWeight.SemiBold)
                    }
                    if (guided) {
                        Spacer(Modifier.height(10.dp))
                        WhiteCard(Modifier.fillMaxWidth()) { Text("Seu roteiro", fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(guidedScript, color = FalaColors.Muted, lineHeight = 20.sp) }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(
                        "Estrutura sugerida: ideia principal → motivo → exemplo → conclusão. Use palavras-chave, não leia um texto inteiro.",
                        color = FalaColors.Muted, lineHeight = 21.sp
                    )
                }
                1 -> {
                    Spacer(Modifier.height(16.dp))
                    Text(speakingTopics[topicIndex], fontSize = 18.sp, lineHeight = 25.sp, color = FalaColors.Navy, fontWeight = FontWeight.SemiBold)
                    if (teleprompter) {
                        Spacer(Modifier.height(12.dp))
                        WhiteCard(Modifier.fillMaxWidth()) { Text("Roteiro", fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(guidedScript, color = FalaColors.Muted, lineHeight = 21.sp) }
                    }
                    Spacer(Modifier.height(40.dp))
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(formatTime(duration - elapsed), fontSize = 72.sp, fontWeight = FontWeight.ExtraBold, color = FalaColors.Blue)
                        Text("restantes", color = FalaColors.Muted)
                        Spacer(Modifier.height(16.dp))
                        LinearProgressIndicator(
                            progress = { (elapsed.toFloat() / duration).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(8.dp),
                            color = FalaColors.Blue, trackColor = FalaColors.Track
                        )
                        Spacer(Modifier.height(20.dp))
                        Text(
                            if (wantRecord && !recordFailed) "● Gravando" else if (recordFailed) "Não foi possível gravar; o cronômetro segue normalmente." else "Fale em voz alta.",
                            color = if (wantRecord && !recordFailed) FalaColors.Red else FalaColors.Muted,
                            fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center
                        )
                    }
                }
                else -> {
                    Spacer(Modifier.height(8.dp))
                    ScreenTitle("Como foi?")
                    Spacer(Modifier.height(6.dp))
                    Text("Você falou por ${formatTime(elapsed)}. Marque o que você cumpriu:", color = FalaColors.Muted)
                    Spacer(Modifier.height(12.dp))
                    speechCriteria.forEachIndexed { i, text ->
                        val on = (criteriaMask shr i) and 1 == 1
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = on, onCheckedChange = { criteriaMask = criteriaMask xor (1 shl i) })
                            Text(text, modifier = Modifier.weight(1f))
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    if (audioName != null) {
                        OutlinedButton(onClick = {
                            if (playing) { player.stop(); playing = false }
                            else playing = player.play(audioName!!) { playing = false }
                        }) {
                            Icon(if (playing) Icons.Default.Stop else Icons.Default.PlayArrow, null)
                            Spacer(Modifier.width(6.dp))
                            Text(if (playing) "Parar" else "Ouvir minha gravação")
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("Ouça com atenção: ritmo, pausas, clareza e entonação.", color = FalaColors.Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(14.dp))
                        WhiteCard(Modifier.fillMaxWidth()) {
                            Text("Vícios de linguagem", fontWeight = FontWeight.Bold)
                            Text(
                                "Ao ouvir, conte quantas vezes você disse “né”, “tipo”, “ééé” ou similares. A contagem é sua, o app não analisa a voz.",
                                color = FalaColors.Muted, fontSize = 12.sp, lineHeight = 17.sp
                            )
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedButton(onClick = { fillers = (fillers - 1).coerceAtLeast(0); fillersCounted = true }) { Text("−") }
                                Text(
                                    if (fillersCounted) "$fillers" else "–",
                                    modifier = Modifier.padding(horizontal = 18.dp),
                                    fontSize = 22.sp, fontWeight = FontWeight.Bold, color = FalaColors.Navy
                                )
                                OutlinedButton(onClick = { fillers += 1; fillersCounted = true }) { Text("+") }
                            }
                        }
                    } else if (recordFailed) {
                        Text("A gravação não pôde ser salva neste treino.", color = FalaColors.Red, fontSize = 13.sp)
                    }
                    if (xpGained >= 0) {
                        Spacer(Modifier.height(12.dp))
                        Text(
                            if (xpGained > 0) "Treino salvo! +$xpGained XP" else "Treino salvo! (o limite de XP de treinos de hoje já foi atingido, ou o treino foi muito curto)",
                            color = FalaColors.Green, fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        when (phase) {
            0 -> BigButton("Começar a falar") { onStartClick() }
            1 -> BigButton("Terminar agora") { finish() }
            else -> {
                if (!saved) {
                    BigButton("Salvar treino") {
                        player.stop(); playing = false
                        var met = 0
                        for (i in speechCriteria.indices) if ((criteriaMask shr i) and 1 == 1) met++
                        xpGained = onSave(
                            SpeakingSession(
                                timestamp = System.currentTimeMillis(),
                                topic = speakingTopics[topicIndex],
                                plannedSeconds = duration,
                                actualSeconds = elapsed,
                                criteriaMet = met,
                                fillerCount = if (fillersCounted) fillers else -1,
                                audioFile = audioName
                            )
                        )
                        saved = true
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = onExit, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("Descartar") }
                } else {
                    BigButton("Concluir", onClick = onExit)
                }
            }
        }
    }
}
