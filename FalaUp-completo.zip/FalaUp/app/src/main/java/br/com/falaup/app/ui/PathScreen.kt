package br.com.falaup.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import br.com.falaup.app.data.ProgressState
import br.com.falaup.app.data.Rules
import br.com.falaup.app.data.lessons

@Composable
fun PathScreen(
    s: ProgressState,
    padding: PaddingValues,
    onOpenLesson: (Int) -> Unit,
    onLocked: () -> Unit
) {
    CenteredContent(Modifier.padding(padding)) {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            item {
                Spacer(Modifier.height(22.dp))
                Eyebrow("TRILHA DE APRENDIZAGEM")
                ScreenTitle("Sua jornada")
                Spacer(Modifier.height(4.dp))
                Text("Conclua cada lição para liberar a próxima. Você precisa acertar pelo menos 2/3 das questões.", color = FalaColors.Muted)
                Spacer(Modifier.height(20.dp))
            }
            items(lessons) { lesson ->
                val locked = !Rules.isUnlocked(s, lesson)
                LessonRow(lesson, done = s.completed.containsKey(lesson.id), locked = locked) {
                    if (locked) onLocked() else onOpenLesson(lesson.id)
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
