package br.com.falaup.app.data

import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** Regras de XP, sequência, desbloqueio e conquistas. Funções puras, fáceis de testar. */
object Rules {
    const val LESSON_XP = 20
    const val PERFECT_BONUS = 10
    const val REVIEW_XP = 5
    const val SPEECH_XP = 10
    const val MAX_SPEECH_XP_PER_DAY = 3
    const val MIN_SPEECH_SECONDS_FOR_XP = 15
    const val XP_PER_LEVEL = 100

    fun level(xp: Int) = xp / XP_PER_LEVEL + 1
    fun xpInLevel(xp: Int) = xp % XP_PER_LEVEL

    fun levelTitle(level: Int) = when {
        level >= 6 -> "Orador(a) experiente"
        level >= 4 -> "Comunicador(a) confiante"
        level >= 2 -> "Aprendiz dedicado(a)"
        else -> "Iniciante"
    }

    /** Mínimo de acertos para passar: 2/3 das questões, arredondado para cima. */
    fun passMark(total: Int) = (total * 2 + 2) / 3

    fun questionKey(lessonId: Int, index: Int) = "$lessonId:$index"

    fun isUnlocked(s: ProgressState, lesson: Lesson): Boolean {
        val i = lessons.indexOfFirst { it.id == lesson.id }
        return i <= 0 || s.completed.containsKey(lessons[i - 1].id)
    }

    fun nextLesson(s: ProgressState): Lesson? = lessons.firstOrNull { !s.completed.containsKey(it.id) }

    fun xpToday(s: ProgressState, today: LocalDate): Int =
        if (s.dailyXpDate == today.toString()) s.dailyXp else 0

    /** Sequência exibida: zera se o último estudo foi há mais de 1 dia. */
    fun currentStreak(s: ProgressState, today: LocalDate): Int {
        val last = parseDate(s.lastStudyDate) ?: return 0
        return if (ChronoUnit.DAYS.between(last, today) <= 1) s.streak else 0
    }

    fun studiedToday(s: ProgressState, today: LocalDate) = s.lastStudyDate == today.toString()

    private fun parseDate(text: String): LocalDate? =
        try { if (text.isBlank()) null else LocalDate.parse(text) } catch (e: Exception) { null }

    private fun touchStudy(s: ProgressState, today: LocalDate): ProgressState {
        val todayStr = today.toString()
        if (s.lastStudyDate == todayStr) return s
        val last = parseDate(s.lastStudyDate)
        val newStreak = if (last != null && ChronoUnit.DAYS.between(last, today) == 1L) s.streak + 1 else 1
        return s.copy(
            streak = newStreak,
            longestStreak = maxOf(s.longestStreak, newStreak),
            lastStudyDate = todayStr
        )
    }

    private fun addXp(s: ProgressState, amount: Int, today: LocalDate): ProgressState {
        if (amount <= 0) return s
        val todayStr = today.toString()
        val base = if (s.dailyXpDate == todayStr) s.dailyXp else 0
        return s.copy(xp = s.xp + amount, dailyXp = base + amount, dailyXpDate = todayStr)
    }

    data class Outcome(val state: ProgressState, val xpEarned: Int, val passed: Boolean, val newAchievements: List<Achievement>)

    fun finishLesson(s: ProgressState, lesson: Lesson, correct: Int, missed: Set<Int>, today: LocalDate): Outcome {
        val total = lesson.questions.size
        val passed = correct >= passMark(total)
        var st = touchStudy(s, today)

        // Erros entram na revisão; acertos nesta tentativa saem dela.
        val wrong = st.wrong.toMutableSet()
        for (i in 0 until total) {
            val key = questionKey(lesson.id, i)
            if (i in missed) wrong.add(key) else wrong.remove(key)
        }
        st = st.copy(wrong = wrong)

        var xp = 0
        if (passed) {
            val first = !st.completed.containsKey(lesson.id)
            val best = maxOf(correct, st.completed[lesson.id] ?: 0)
            st = st.copy(completed = st.completed + (lesson.id to best))
            if (first) {
                xp = LESSON_XP + if (correct == total) PERFECT_BONUS else 0
                st = addXp(st, xp, today)
            }
        }
        return withAchievements(st, xp, passed)
    }

    fun answerReview(s: ProgressState, key: String, correct: Boolean, today: LocalDate): Outcome {
        var st = touchStudy(s, today)
        var xp = 0
        if (correct && key in st.wrong) {
            st = st.copy(wrong = st.wrong - key, reviewedCorrect = st.reviewedCorrect + 1)
            xp = REVIEW_XP
            st = addXp(st, xp, today)
        }
        return withAchievements(st, xp, correct)
    }

    fun addSession(s: ProgressState, session: SpeakingSession, today: LocalDate): Outcome {
        var st = touchStudy(s, today)
        val todayStr = today.toString()
        val count = if (st.speakingXpDate == todayStr) st.speakingXpCount else 0
        var xp = 0
        if (session.actualSeconds >= MIN_SPEECH_SECONDS_FOR_XP && count < MAX_SPEECH_XP_PER_DAY) {
            xp = SPEECH_XP
            st = addXp(st, xp, today).copy(speakingXpDate = todayStr, speakingXpCount = count + 1)
        }
        st = st.copy(sessions = (listOf(session) + st.sessions).take(MAX_SESSIONS))
        return withAchievements(st, xp, true)
    }

    const val MAX_SESSIONS = 100

    private fun satisfied(s: ProgressState): Set<String> {
        val ids = mutableSetOf<String>()
        if (s.completed.isNotEmpty()) ids += "first_lesson"
        if (s.completed.size >= 5) ids += "five_lessons"
        if (lessons.all { s.completed.containsKey(it.id) }) ids += "all_lessons"
        if (lessons.any { (s.completed[it.id] ?: -1) == it.questions.size }) ids += "perfect"
        if (s.longestStreak >= 3) ids += "streak3"
        if (s.longestStreak >= 7) ids += "streak7"
        if (s.sessions.isNotEmpty()) ids += "first_speech"
        if (s.sessions.size >= 5) ids += "five_speeches"
        if (s.reviewedCorrect >= 5) ids += "reviewer"
        if (s.sessions.count { it.audioFile != null && it.fillerCount >= 0 } >= 3) ids += "fillers_aware"
        return ids
    }

    private fun withAchievements(s: ProgressState, xp: Int, passed: Boolean): Outcome {
        val fresh = satisfied(s) - s.achievements
        val list = achievementList.filter { it.id in fresh }
        return Outcome(s.copy(achievements = s.achievements + fresh), xp, passed, list)
    }
}
