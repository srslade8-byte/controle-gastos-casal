package br.com.falaup.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object FalaColors {
    val Navy = Color(0xFF12356A)
    val Blue = Color(0xFF246BFD)
    val BlueSoft = Color(0xFFE5EEFF)
    val Pale = Color(0xFFF2F6FF)
    val Background = Color(0xFFF7F9FE)
    val Ink = Color(0xFF17243A)
    val Muted = Color(0xFF5B6B85)
    val Green = Color(0xFF16845B)
    val GreenSoft = Color(0xFFE1F6EC)
    val Red = Color(0xFFB3261E)
    val RedSoft = Color(0xFFFFE9E8)
    val Track = Color(0xFFDCE6FA)
}

@Composable
fun FalaUpTheme(dark: Boolean = false, largeText: Boolean = false, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(
            primary = Color(0xFF8DB4FF),
            secondary = Color(0xFFB9C9FF),
            background = Color(0xFF101522),
            surface = Color(0xFF182033),
            onBackground = Color(0xFFE8ECF7),
            onSurface = Color(0xFFE8ECF7)
        ) else lightColorScheme(
            primary = FalaColors.Blue,
            onPrimary = Color.White,
            secondary = FalaColors.Navy,
            background = FalaColors.Background,
            surface = Color.White,
            onBackground = FalaColors.Ink,
            onSurface = FalaColors.Ink,
            primaryContainer = FalaColors.BlueSoft,
            onPrimaryContainer = FalaColors.Navy
        ),
        typography = if (largeText) androidx.compose.material3.Typography().run {
            copy(bodyLarge = bodyLarge.copy(fontSize = bodyLarge.fontSize * 1.15f),
                bodyMedium = bodyMedium.copy(fontSize = bodyMedium.fontSize * 1.15f))
        } else androidx.compose.material3.Typography(),
        content = content
    )
}
