package br.com.falaup.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.falaup.app.data.ProgressState
import br.com.falaup.app.data.Rules
import br.com.falaup.app.data.lessons
import java.time.LocalDate

@Composable
fun HomeScreen(
    s: ProgressState,
    padding: PaddingValues,
    onOpenLesson: (Int) -> Unit,
    onSpeak: () -> Unit,
    onReview: () -> Unit
) {
    val today = LocalDate.now()
    val level = Rules.level(s.xp)
    val xpToday = Rules.xpToday(s, today)
    val streak = Rules.currentStreak(s, today)
    val next = Rules.nextLesson(s)
    val goalProgress = (xpToday.toFloat() / s.dailyGoal).coerceIn(0f, 1f)

    CenteredContent(Modifier.padding(padding)) {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            item {
                Spacer(Modifier.height(20.dp))
                Eyebrow("FALAUP")
                Spacer(Modifier.height(6.dp))
                Text(
                    "Sua voz.\nSua evolução.",
                    fontSize = 32.sp, lineHeight = 38.sp,
                    fontWeight = FontWeight.ExtraBold, color = FalaColors.Navy
                )
                Text("Foco de hoje: ${s.goalPurpose}", color = FalaColors.Muted, fontSize = 14.sp)
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("⚡ ${s.xp} XP", "Nível $level", Modifier.weight(1f))
                    StatCard("🔥 $streak ${if (streak == 1) "dia" else "dias"}", "Sequência de estudo", Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))

                WhiteCard(Modifier.fillMaxWidth()) {
                    Text("Meta de hoje", fontWeight = FontWeight.Bold, color = FalaColors.Navy, fontSize = 17.sp)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { goalProgress },
                        modifier = Modifier.fillMaxWidth().height(8.dp),
                        color = if (goalProgress >= 1f) FalaColors.Green else FalaColors.Blue,
                        trackColor = FalaColors.Track
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (goalProgress >= 1f) "Meta cumprida! Continue treinando." else "$xpToday de ${s.dailyGoal} XP hoje",
                        color = FalaColors.Muted, fontSize = 13.sp
                    )
                }
                Spacer(Modifier.height(12.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = FalaColors.Blue),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Text(
                            if (next == null) "TRILHA COMPLETA" else "CONTINUE DE ONDE PAROU",
                            color = Color.White.copy(alpha = .8f), fontSize = 11.sp, fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            next?.title ?: "Revise e mantenha a prática",
                            color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "${s.completed.size} de ${lessons.size} lições concluídas",
                            color = Color.White.copy(alpha = .9f)
                        )
                        Spacer(Modifier.height(14.dp))
                        Button(
                            onClick = { if (next != null) onOpenLesson(next.id) else onSpeak() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = FalaColors.Blue),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (next != null) "Continuar lição" else "Treinar a fala", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(8.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, null)
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))

                WhiteCard(Modifier.fillMaxWidth(), onClick = onSpeak) {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        IconBubble(Icons.Default.RecordVoiceOver)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Treino de fala", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("30 s, 1 min ou 2 min com tema sorteado", color = FalaColors.Muted, fontSize = 13.sp)
                        }
                    }
                }
                if (s.wrong.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    WhiteCard(Modifier.fillMaxWidth(), onClick = onReview) {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            IconBubble(Icons.Default.Replay)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Revisar erros", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text("${s.wrong.size} questão(ões) para rever", color = FalaColors.Muted, fontSize = 13.sp)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text("Próximas lições", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = FalaColors.Navy)
                Spacer(Modifier.height(8.dp))
            }
            val upcoming = lessons.filter { !s.completed.containsKey(it.id) }.take(3)
            items(upcoming) { lesson ->
                val locked = !Rules.isUnlocked(s, lesson)
                LessonRow(lesson, done = false, locked = locked) { if (!locked) onOpenLesson(lesson.id) }
            }
            item { Spacer(Modifier.height(18.dp)) }
        }
    }
}
