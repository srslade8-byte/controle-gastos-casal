package br.com.falaup.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.falaup.app.data.Lesson
import br.com.falaup.app.data.Question
import br.com.falaup.app.data.QuestionKind
import br.com.falaup.app.data.answerTokens
import br.com.falaup.app.data.isComplete
import br.com.falaup.app.data.isCorrect
import br.com.falaup.app.data.displayOrder
import br.com.falaup.app.data.Rules

/** Mostra uma pergunta (escolha ou ordenar) e, depois de conferida, a explicação. */
@Composable
fun QuestionView(q: Question, answer: String, checked: Boolean, onAnswer: (String) -> Unit) {
    Text(q.prompt, color = FalaColors.Navy, fontSize = 22.sp, fontWeight = FontWeight.Bold, lineHeight = 29.sp)
    Spacer(Modifier.height(18.dp))
    if (q.kind == QuestionKind.CHOICE) {
        val chosen = answer.trim().toIntOrNull() ?: -1
        q.options.forEachIndexed { i, option ->
            val bg = when {
                checked && i == q.correct -> FalaColors.GreenSoft
                checked && chosen == i -> FalaColors.RedSoft
                chosen == i -> FalaColors.BlueSoft
                else -> Color.White
            }
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable(enabled = !checked) { onAnswer(i.toString()) },
                colors = CardDefaults.cardColors(containerColor = bg),
                border = if (chosen == i) BorderStroke(1.dp, FalaColors.Blue) else null,
                shape = RoundedCornerShape(15.dp)
            ) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${'A' + i}", color = FalaColors.Blue, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(12.dp))
                    Text(option, modifier = Modifier.weight(1f), fontSize = 15.sp)
                    if (checked && i == q.correct) Icon(Icons.Default.CheckCircle, "Resposta correta", tint = FalaColors.Green)
                }
            }
        }
    } else {
        val picked = answerTokens(answer)
        Text("Toque nos itens na ordem correta. Toque de novo para desfazer.", color = FalaColors.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        q.displayOrder().forEach { idx ->
            val pos = picked.indexOf(idx)
            val bg = when {
                checked && pos == idx -> FalaColors.GreenSoft
                checked -> FalaColors.RedSoft
                pos >= 0 -> FalaColors.BlueSoft
                else -> Color.White
            }
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable(enabled = !checked) {
                    val next = if (pos >= 0) picked.filter { it != idx } else picked + idx
                    onAnswer(next.joinToString(","))
                },
                colors = CardDefaults.cardColors(containerColor = bg),
                border = if (pos >= 0) BorderStroke(1.dp, FalaColors.Blue) else null,
                shape = RoundedCornerShape(15.dp)
            ) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (pos >= 0) "${pos + 1}" else "•", color = FalaColors.Blue, fontWeight = FontWeight.Bold, modifier = Modifier.width(22.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(q.options[idx], modifier = Modifier.weight(1f), fontSize = 15.sp)
                }
            }
        }
    }
    if (checked) {
        val ok = q.isCorrect(answer)
        Spacer(Modifier.height(4.dp))
        WhiteCard(Modifier.fillMaxWidth()) {
            Text(
                if (ok) "Correto!" else "Quase lá.",
                fontWeight = FontWeight.Bold,
                color = if (ok) FalaColors.Green else FalaColors.Red
            )
            if (q.kind == QuestionKind.ORDER && !ok) {
                Spacer(Modifier.height(4.dp))
                Text("Ordem correta:", fontWeight = FontWeight.SemiBold, color = FalaColors.Navy)
                q.options.forEachIndexed { i, text -> Text("${i + 1}. $text", color = FalaColors.Ink, lineHeight = 20.sp) }
            }
            Spacer(Modifier.height(4.dp))
            Text(q.explanation, color = FalaColors.Ink, lineHeight = 21.sp)
        }
    }
}

@Composable
fun LessonScreen(
    lesson: Lesson,
    onExit: () -> Unit,
    onFinish: (correct: Int, missed: Set<Int>) -> Rules.Outcome,
    onPractice: () -> Unit
) {
    val n = lesson.questions.size
    val resultStep = n + 1
    var step by rememberSaveable(lesson.id) { mutableIntStateOf(0) }
    var answer by rememberSaveable(lesson.id) { mutableStateOf("") }
    var checked by rememberSaveable(lesson.id) { mutableStateOf(false) }
    var correctCount by rememberSaveable(lesson.id) { mutableIntStateOf(0) }
    var missedMask by rememberSaveable(lesson.id) { mutableIntStateOf(0) }
    var recorded by rememberSaveable(lesson.id) { mutableStateOf(false) }
    var xpEarned by rememberSaveable(lesson.id) { mutableIntStateOf(0) }

    val passed = correctCount >= Rules.passMark(n)

    LaunchedEffect(step) {
        if (step == resultStep && !recorded) {
            val missed = (0 until n).filter { (missedMask shr it) and 1 == 1 }.toSet()
            val outcome = onFinish(correctCount, missed)
            xpEarned = outcome.xpEarned
            recorded = true
        }
    }

    CenteredContent(Modifier.background(FalaColors.Background).statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onExit) { Icon(Icons.Default.Close, "Sair da lição", tint = FalaColors.Navy) }
            LinearProgressIndicator(
                progress = { (step.toFloat() / resultStep).coerceIn(0f, 1f) },
                modifier = Modifier.weight(1f).height(8.dp),
                color = FalaColors.Blue, trackColor = FalaColors.Track
            )
        }
        Spacer(Modifier.height(16.dp))

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            when {
                step == 0 -> {
                    Eyebrow(lesson.unit)
                    Spacer(Modifier.height(8.dp))
                    Text(lesson.title, color = FalaColors.Navy, fontSize = 28.sp, lineHeight = 34.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(14.dp))
                    WhiteCard(Modifier.fillMaxWidth()) {
                        Text("OBJETIVO", color = FalaColors.Blue, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(lesson.objective, fontSize = 15.sp, lineHeight = 22.sp)
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(lesson.intro, fontSize = 17.sp, lineHeight = 26.sp, color = FalaColors.Ink)
                    Spacer(Modifier.height(16.dp))
                    WhiteCard(Modifier.fillMaxWidth()) {
                        Text("EXEMPLO PRÁTICO", color = FalaColors.Blue, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(lesson.example, fontSize = 15.sp, lineHeight = 22.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                }
                step in 1..n -> {
                    val index = step - 1
                    Eyebrow("EXERCÍCIO $step DE $n")
                    Spacer(Modifier.height(12.dp))
                    QuestionView(lesson.questions[index], answer, checked) { answer = it }
                    Spacer(Modifier.height(12.dp))
                }
                else -> {
                    Column(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            if (passed) Icons.Default.EmojiEvents else Icons.Default.Replay, null,
                            tint = FalaColors.Blue, modifier = Modifier.size(76.dp)
                        )
                        Spacer(Modifier.height(14.dp))
                        Text(
                            if (passed) "Lição concluída!" else "Quase lá!",
                            color = FalaColors.Navy, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("$correctCount de $n respostas corretas", color = FalaColors.Muted)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            when {
                                !passed -> "Você precisa de ${Rules.passMark(n)} acertos para concluir. As questões erradas foram para a revisão."
                                xpEarned > 0 -> "+$xpEarned XP ganhos!"
                                else -> "Você já tinha concluído esta lição, então não há XP novo."
                            },
                            color = if (passed && xpEarned > 0) FalaColors.Green else FalaColors.Muted,
                            fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center
                        )
                        if (passed) {
                            Spacer(Modifier.height(20.dp))
                            WhiteCard(Modifier.fillMaxWidth()) {
                                Text("DESAFIO PRÁTICO", color = FalaColors.Blue, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Spacer(Modifier.height(6.dp))
                                Text(lesson.challenge, lineHeight = 22.sp)
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        when {
            step == 0 -> BigButton("Entendi, ir para os exercícios") { step = 1 }
            step in 1..n -> {
                val q = lesson.questions[step - 1]
                BigButton(
                    text = when {
                        !checked -> "Conferir resposta"
                        step < n -> "Próxima questão"
                        else -> "Ver resultado"
                    },
                    enabled = q.isComplete(answer)
                ) {
                    if (!checked) {
                        checked = true
                        if (q.isCorrect(answer)) correctCount++ else missedMask = missedMask or (1 shl (step - 1))
                    } else {
                        step++
                        answer = ""
                        checked = false
                    }
                }
            }
            else -> {
                if (passed) {
                    OutlinedButton(
                        onClick = onPractice,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) { Text("Fazer o treino de fala") }
                    Spacer(Modifier.height(8.dp))
                    BigButton("Continuar", onClick = onExit)
                } else {
                    BigButton("Tentar novamente") {
                        step = 0; answer = ""; checked = false
                        correctCount = 0; missedMask = 0; recorded = false; xpEarned = 0
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = onExit,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) { Text("Voltar à trilha") }
                }
            }
        }
    }
}
