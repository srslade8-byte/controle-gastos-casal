package br.com.falaup.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.falaup.app.data.Lesson

/** Limita a largura do conteúdo em telas grandes (tablets, modo paisagem). */
@Composable
fun CenteredContent(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = 640.dp).fillMaxSize(), content = content)
    }
}

@Composable
fun Eyebrow(text: String) {
    Text(text, color = FalaColors.Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
}

@Composable
fun ScreenTitle(text: String) {
    Text(text, fontSize = 30.sp, lineHeight = 36.sp, fontWeight = FontWeight.ExtraBold, color = FalaColors.Navy)
}

@Composable
fun WhiteCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val m = if (onClick != null) modifier.clickable { onClick() } else modifier
    Card(
        modifier = m,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) { Column(Modifier.padding(18.dp), content = content) }
}

@Composable
fun StatCard(title: String, subtitle: String, modifier: Modifier = Modifier) {
    WhiteCard(modifier) {
        Text(title, color = FalaColors.Navy, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(3.dp))
        Text(subtitle, color = FalaColors.Muted, fontSize = 12.sp)
    }
}

@Composable
fun IconBubble(icon: ImageVector, tint: Color = FalaColors.Blue, bg: Color = FalaColors.Pale, size: Int = 48) {
    Box(Modifier.size(size.dp).background(bg, CircleShape), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size((size * 0.5f).dp))
    }
}

@Composable
fun LessonRow(lesson: Lesson, done: Boolean, locked: Boolean, onClick: () -> Unit) {
    val stateText = when {
        locked -> "Bloqueada"
        done -> "Concluída"
        else -> "${lesson.minutes} min · ${lesson.questions.size} exercícios"
    }
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = if (locked) Color(0xFFEEF1F7) else Color.White),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            when {
                locked -> IconBubble(Icons.Default.Lock, FalaColors.Muted, Color(0xFFDDE3EE))
                done -> IconBubble(Icons.Default.CheckCircle, FalaColors.Green, FalaColors.GreenSoft)
                else -> IconBubble(Icons.Default.School)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(lesson.unit, color = if (locked) FalaColors.Muted else FalaColors.Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(lesson.title, color = if (locked) FalaColors.Muted else FalaColors.Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(stateText, color = FalaColors.Muted, fontSize = 12.sp)
            }
            if (!locked) Icon(Icons.Default.ChevronRight, null, tint = FalaColors.Muted)
        }
    }
}

@Composable
fun BigButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(54.dp),
        shape = RoundedCornerShape(16.dp)
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

fun formatTime(totalSeconds: Int): String {
    val m = totalSeconds / 60
    val s = totalSeconds % 60
    return "%d:%02d".format(m, s)
}
