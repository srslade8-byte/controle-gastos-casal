package br.com.falaup.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import br.com.falaup.app.audio.recordingsDir
import br.com.falaup.app.data.Lesson
import br.com.falaup.app.data.ProgressState
import br.com.falaup.app.data.ProgressStore
import br.com.falaup.app.data.Rules
import br.com.falaup.app.data.SpeakingSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.time.LocalDate
import org.json.JSONObject

class FalaUpViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ProgressStore(app)
    private val _state = MutableStateFlow(store.load())
    val state: StateFlow<ProgressState> = _state

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    fun consumeMessage() { _message.value = null }

    private fun commit(outcome: Rules.Outcome) {
        _state.value = outcome.state
        store.save(outcome.state)
        outcome.newAchievements.firstOrNull()?.let { _message.value = "Conquista desbloqueada: ${it.title}" }
    }

    fun finishLesson(lesson: Lesson, correct: Int, missed: Set<Int>): Rules.Outcome {
        val o = Rules.finishLesson(_state.value, lesson, correct, missed, LocalDate.now())
        commit(o)
        return o
    }

    fun answerReview(key: String, correct: Boolean) {
        commit(Rules.answerReview(_state.value, key, correct, LocalDate.now()))
    }

    fun addSession(session: SpeakingSession): Int {
        val o = Rules.addSession(_state.value, session, LocalDate.now())
        // Apaga os áudios das sessões que saíram do histórico.
        val dropped = (_state.value.sessions + session).filter { old -> o.state.sessions.none { it.timestamp == old.timestamp } }
        dropped.forEach { deleteAudio(it.audioFile) }
        commit(o)
        return o.xpEarned
    }

    fun deleteSession(timestamp: Long) {
        val s = _state.value
        val target = s.sessions.firstOrNull { it.timestamp == timestamp } ?: return
        deleteAudio(target.audioFile)
        val next = s.copy(sessions = s.sessions - target)
        _state.value = next
        store.save(next)
    }

    fun setDailyGoal(xp: Int) {
        val next = _state.value.copy(dailyGoal = xp)
        _state.value = next
        store.save(next)
    }

    fun finishOnboarding(purpose: String, goal: Int) = updatePreferences {
        it.copy(onboardingDone = true, goalPurpose = purpose, dailyGoal = goal)
    }

    fun setDarkMode(value: Boolean) = updatePreferences { it.copy(darkMode = value) }
    fun setLargeText(value: Boolean) = updatePreferences { it.copy(largeText = value) }
    fun setReminder(enabled: Boolean, hour: Int = _state.value.reminderHour, minute: Int = _state.value.reminderMinute) =
        updatePreferences { it.copy(reminderEnabled = enabled, reminderHour = hour, reminderMinute = minute) }.also {
            ReminderScheduler.ensureChannel(getApplication())
            ReminderScheduler.set(getApplication(), enabled, hour, minute)
        }

    fun exportProgress(): String = ProgressStore.toJson(_state.value).toString(2)

    fun importProgress(raw: String) {
        try {
            val next = ProgressStore.fromJson(JSONObject(raw))
            _state.value = next
            store.save(next)
            _message.value = "Backup importado com sucesso."
        } catch (_: Exception) {
            _message.value = "Não foi possível importar este arquivo."
        }
    }

    private fun updatePreferences(transform: (ProgressState) -> ProgressState) {
        val next = transform(_state.value)
        _state.value = next
        store.save(next)
    }

    fun resetAll() {
        recordingsDir(getApplication()).listFiles()?.forEach { it.delete() }
        _state.value = ProgressState()
        store.save(_state.value)
    }

    private fun deleteAudio(name: String?) {
        if (name == null) return
        try { File(recordingsDir(getApplication()), name).delete() } catch (_: Exception) {}
    }
}
