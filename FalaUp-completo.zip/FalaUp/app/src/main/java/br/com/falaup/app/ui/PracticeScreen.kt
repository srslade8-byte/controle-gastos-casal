package br.com.falaup.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircleOutline
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.falaup.app.data.tongueTwisters

val speechCriteria = listOf(
    "Apresentei a ideia principal?",
    "Expliquei o motivo ou a razão?",
    "Dei pelo menos um exemplo concreto?",
    "Concluí sem fugir do tema?"
)

@Composable
fun PracticeScreen(padding: PaddingValues, sessionCount: Int, onStartSpeech: () -> Unit) {
    var twister by rememberSaveable { mutableIntStateOf(0) }
    CenteredContent(Modifier.padding(padding)) {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            item {
                Spacer(Modifier.height(22.dp))
                Eyebrow("TREINO")
                ScreenTitle("Treine sua fala")
                Spacer(Modifier.height(8.dp))
                Text(
                    "A prática transforma conhecimento em habilidade. Fale em voz alta, avalie-se e repita.",
                    color = FalaColors.Muted, lineHeight = 22.sp
                )
                Spacer(Modifier.height(18.dp))

                WhiteCard(Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Mic, null, tint = FalaColors.Blue, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Treino de fala com cronômetro", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = FalaColors.Navy)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Sorteie um tema, escolha 30 s, 1 min ou 2 min e, se quiser, grave sua voz para ouvir depois. " +
                            "Treinos feitos: $sessionCount.",
                        lineHeight = 22.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    BigButton("Começar treino", onClick = onStartSpeech)
                }
                Spacer(Modifier.height(14.dp))

                WhiteCard(Modifier.fillMaxWidth()) {
                    Eyebrow("DICÇÃO")
                    Spacer(Modifier.height(8.dp))
                    Text(tongueTwisters[twister], fontSize = 19.sp, lineHeight = 26.sp, fontWeight = FontWeight.SemiBold, color = FalaColors.Navy)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Diga devagar, articulando cada sílaba. Repita 3 vezes e só então aumente a velocidade.",
                        color = FalaColors.Muted, fontSize = 13.sp, lineHeight = 19.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { twister = (twister + 1) % tongueTwisters.size }) { Text("Outro trava-língua") }
                }
                Spacer(Modifier.height(14.dp))

                WhiteCard(Modifier.fillMaxWidth()) {
                    Eyebrow("CHECKLIST DE AUTOAVALIAÇÃO")
                    Spacer(Modifier.height(10.dp))
                    speechCriteria.forEach {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 5.dp)) {
                            Icon(Icons.Default.CheckCircleOutline, null, tint = FalaColors.Blue)
                            Spacer(Modifier.width(10.dp)); Text(it)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "O FalaUp não analisa sua voz automaticamente: a avaliação é feita por você, com base nesses critérios.",
                        color = FalaColors.Muted, fontSize = 12.sp, lineHeight = 17.sp
                    )
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
