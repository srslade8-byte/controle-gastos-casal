# FalaUp — Android

Aplicativo de aprendizado de oratória. Kotlin + Jetpack Compose. Azul e branco.
Slogan: **Sua voz. Sua evolução.**

## Abrir no Android Studio
1. Extraia o ZIP. 2. **File > Open** e escolha a pasta `FalaUp` (a que contém `settings.gradle.kts`).
3. Aguarde o **Gradle Sync**. 4. Escolha `app` e clique em **Run**.

## Configuração
- Application ID: `br.com.falaup.app` | versão 1.2.0 (código 3)
- compileSdk/targetSdk 36 (exigência do Google Play para novos apps desde 31/08/2026), minSdk 26
- AGP 8.9.1, Kotlin 2.0.21, Compose BOM 2025.02.00

## Estrutura
- `data/` modelos, conteúdo das lições, regras (XP, sequência, bloqueio, conquistas) e salvamento
- `audio/` gravação e reprodução da voz (arquivo privado no aparelho)
- `ui/` telas: Início, Trilha, Lição, Revisão, Treino de fala, Prática, Perfil
- `FalaUpViewModel.kt` conecta regras, salvamento e telas

## Regras de pontuação
- Passar na lição = acertar ≥ 2/3 das questões. Primeira conclusão: +20 XP (+10 se acertar tudo). Repetir não dá XP.
- Revisão de erro corrigido: +5 XP, uma vez por questão.
- Treino de fala ≥ 15 s: +10 XP, até 3 por dia.
- Nível = 100 XP. Sequência conta qualquer atividade do dia.

## Documentos
- `docs/PUBLICAR.md` passo a passo, `docs/LOJA.md` ficha da loja, `docs/PRIVACIDADE.md` rascunho de política

## Entregue nesta versão
- Boas-vindas com objetivo (falar em público, entrevista ou trabalho) e meta diária.
- Preferências locais de modo escuro, fonte maior e lembrete diário opcional por notificação do Android.
- Exportação do progresso em JSON por compartilhamento do sistema.
- Importação de backup JSON em outro aparelho.
- Gráfico simples de duração dos treinos no perfil e objetivo visível na tela inicial.
- Treino guiado opcional com roteiro, teleprompter e aquecimento vocal de 2 minutos.
- Conteúdo e gravações continuam locais; nenhuma conta, servidor ou publicidade foi adicionada.

## Próxima validação antes da loja
Assinatura de release, AAB, política de privacidade publicada, ficha da loja, testes em aparelho real (incluindo TalkBack, Android antigo, celular pequeno e tablet), revisão por especialista e verificação de marca/nome.
Reconhecimento automático de fala/transcrição, comparação automática de gravações, revisão espaçada adaptativa e simulações em sequência ficam como etapa futura, pois precisam de testes de precisão e privacidade no Android real.
