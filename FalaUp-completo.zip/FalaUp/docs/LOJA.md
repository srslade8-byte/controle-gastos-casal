# Ficha da Play Store (rascunho)

**Nome (máx. 30 caracteres):** FalaUp: Oratória e Fala
**Descrição curta (máx. 80):** Aprenda a falar melhor com lições rápidas, treino de fala e metas diárias.

**Descrição completa:**
Quer falar com mais clareza, confiança e organização? O FalaUp é um curso de oratória em lições curtas, para estudar no seu ritmo.

• 18 lições em português: medo de falar, organização de ideias, respiração, dicção, entonação, postura, storytelling, entrevista de emprego, apresentações, reuniões, conversas difíceis e mais.
• Exercícios de escolha e de ordenar, com explicação de cada resposta.
• Revisão dos erros para fixar o que você errou.
• Treino de fala com cronômetro de 30 s, 1 min ou 2 min e temas sorteados.
• Gravação opcional da sua voz (fica só no seu aparelho) para você ouvir e se avaliar.
• XP, níveis, sequência de dias, metas diárias e conquistas.
• Sem cadastro e sem anúncios.

Importante: o FalaUp não faz análise automática da sua voz. A avaliação do treino é feita por você, com critérios claros.

**Categoria sugerida:** Educação
**Classificação indicativa:** responder ao questionário no Play Console (conteúdo educativo, sem violência nem conteúdo sensível).

**Capturas de tela (tirar no aparelho):** Início, Trilha, uma Lição, Treino de fala, Perfil.
**Ícone:** 512×512 PNG (exportar do ícone do app) e imagem de destaque 1024×500 — a criar.

**Formulário de segurança de dados (conferir no Play Console):** na versão atual os dados ficam apenas no aparelho e não são enviados a servidores. Responda conforme a realidade do app e atualize se adicionar contas, nuvem, anúncios ou análise.
