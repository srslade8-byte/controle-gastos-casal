# Passo a passo para publicar (Windows + Android Studio)

## 1. Antes de tudo
1. Rode o app em um celular real (ou emulador) e teste: lições, revisão, treino de fala, gravação, perfil.
2. Abra **View > Tool Windows > Gradle** e rode os testes: `app > Tasks > verification > testDebugUnitTest`.
3. Confirme que o nome FalaUp e o pacote `br.com.falaup.app` estão disponíveis (Play Console e busca de marcas no INPI). O pacote não pode mudar depois de publicar.

## 2. Criar a chave de assinatura (uma vez só)
1. **Build > Generate Signed Bundle / APK > Android App Bundle > Next**.
2. Em **Key store path**, clique em **Create new...** e salve o arquivo `.jks` **fora** da pasta do projeto.
3. Preencha senha, alias (`falaup`) e dados. **Guarde o .jks e as senhas em lugar seguro (e faça cópia).**
4. Copie `keystore.properties.exemplo` para `keystore.properties` e preencha com o caminho e as senhas.

## 3. Gerar o AAB
**Build > Generate Signed Bundle / APK > Android App Bundle > release.** O arquivo `.aab` aparece em `app/release/`.

## 4. Play Console
1. Crie a conta de desenvolvedor (há taxa única; confira os requisitos atuais).
2. Crie o app, preencha a ficha (veja `LOJA.md`), a política de privacidade (`PRIVACIDADE.md`, publicada em um link), o formulário de segurança de dados e a classificação indicativa.
3. Envie o `.aab` primeiro em **Teste interno**.
4. Contas pessoais novas costumam precisar de um **teste fechado** com um número mínimo de testadores por um período antes de ir para produção. **Confira a regra atual no Play Console**, ela já mudou antes.

## 5. Depois do lançamento
A cada nova versão, aumente `versionCode` em `app/build.gradle.kts` (hoje 3) e ajuste `versionName`.
