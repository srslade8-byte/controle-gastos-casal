# Política de Privacidade do FalaUp (RASCUNHO)

> Rascunho para você revisar e publicar em um endereço público (por exemplo, uma página do GitHub Pages ou um site seu). A Google Play exige o link. Preencha os campos entre [colchetes]. Se possível, peça revisão jurídica, especialmente por causa da LGPD.

**Última atualização:** [data]
**Responsável:** [seu nome ou nome da empresa] — contato: [e-mail]

## O que o FalaUp faz com seus dados
O FalaUp funciona **no seu aparelho**. Na versão atual, o app não exige cadastro, não envia seus dados para servidores nossos, não usa publicidade e não usa ferramentas de rastreamento.

## Dados armazenados no aparelho
- **Progresso:** lições concluídas, XP, nível, sequência de dias, conquistas, meta diária e histórico de treinos.
- **Gravações de voz (opcional):** se você ativar "Gravar minha voz" no treino de fala, o áudio é salvo em uma área privada do app, no seu aparelho. Só você pode ouvi-lo pelo app, e pode apagá-lo a qualquer momento no Perfil.

Esses dados não saem do aparelho. Se você desinstalar o app ou apagar os dados dele, eles são removidos.

## Permissão de microfone
Usada **somente** quando você escolhe gravar sua voz durante um treino. Você pode negar a permissão e continuar usando o app sem gravação.

## Seus direitos
Como os dados ficam no seu aparelho, você controla tudo: pode apagar treinos individualmente, usar "Apagar todo o meu progresso" no Perfil ou desinstalar o app.

## Crianças
O FalaUp não é direcionado a crianças menores de [idade — defina conforme a classificação indicativa].

## Mudanças nesta política
Se o app passar a coletar ou compartilhar dados (por exemplo, com contas, nuvem, anúncios ou análise de uso), esta política será atualizada **antes** do lançamento da mudança.

## Contato
[e-mail de contato]
